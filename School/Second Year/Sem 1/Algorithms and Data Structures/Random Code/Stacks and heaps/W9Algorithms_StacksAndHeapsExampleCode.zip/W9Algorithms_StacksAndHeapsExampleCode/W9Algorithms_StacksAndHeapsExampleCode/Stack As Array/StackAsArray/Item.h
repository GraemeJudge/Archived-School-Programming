#pragma once

typedef struct item Item; 
struct item {
	char itemText[30]; 
	int num; 
	char operation; 
};

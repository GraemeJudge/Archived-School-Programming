#pragma once

typedef struct item Item; 
struct item {
	int priority;
	char itemText[140]; 
	int num; 
};


#pragma once

typedef struct item Item; 
struct item {
	int priority;
	char itemText[30]; 
	int num; 
};


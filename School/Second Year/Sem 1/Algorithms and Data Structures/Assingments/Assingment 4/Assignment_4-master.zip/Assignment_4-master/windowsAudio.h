void recordAndSave(char fileName[]);
int saveToFile( char fileName[]);
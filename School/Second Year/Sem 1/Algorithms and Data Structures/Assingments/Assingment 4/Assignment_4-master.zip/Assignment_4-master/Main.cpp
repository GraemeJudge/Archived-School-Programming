/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/
#include "FileIO.h"
#include "huffman.h"
#include "RLE.h"
#include "String.h"
#include "windowsAudio.h"

void demoHuffman(const char* fileName);
void demoRLE(const char* fileName);
void displayMenu();
void DEMOHuffmanAudio();
long GetFileSize(const char* filename);

void main() {
	displayMenu();
}

void displayMenu() {
	system("@cls||clear");
	printf("---SELECT OPTION---\n1: Compressible Huffman \n2: Uncompressible Huffman \n3: Compressible RLE\n4: Uncompressible RLE\n5: Huffman Audio\n");

	char buf[1024];
	int userInput;
	do {
		printf("Please pick an option between 1 and 5: ");
		fgets(buf, 1024, stdin);
		userInput = atoi(buf);
	} while (userInput < 1 || userInput > 5);
	switch (userInput) {
		case 1:
			demoHuffman(canCompress);
			break;
		case 2:
			demoHuffman(cantCompress);
			break;
		case 3:
			demoRLE(canCompress);
			break;
		case 4:
			demoRLE(cantCompress);
			break;
		case 5:
			DEMOHuffmanAudio();
			break;
		default:
			printf("oops there was an error\n");
	}
	system("pause");
	displayMenu();
}

void demoRLE(const char* fileName) {
	int numChars = getNumChars(fileName);
	char* myString = (char*)malloc(sizeof(char) * numChars);
	getData(myString, fileName, numChars);
	unsigned char* outString = (unsigned char*)malloc(sizeof(unsigned char) * numChars);
	unsigned char* decompressedString = (unsigned char*)malloc(sizeof(unsigned char) * numChars);
	RLECompress((unsigned char*)myString,numChars, outString, numChars, 'A');

	int lenIn = strlen((char*)myString);
	int lenOut = strlen((char*)outString);

	printf("input:\t\t\t%s\n", myString);
	printf("output:\t\t\t%s\n", outString);

	printf("size of input:\t\t%d\n", lenIn);
	printf("size of output:\t\t%d\n", lenOut);
	printf("compression ratio:\t%.2f", (float)((float)lenOut / (float)lenIn));
	RLEDecompress((unsigned char*)outString, strlen((char*)outString), decompressedString, strlen((char*)decompressedString), 'A');
	printf("\nDecompressed string:\t%s\n", decompressedString);
}


void demoHuffman(const char* fileName) {
	int inputSize = getNumChars(fileName);

	unsigned char* input = (unsigned char*)malloc(sizeof(unsigned char) * inputSize);
	unsigned char* output = (unsigned char*)malloc((sizeof(unsigned char) * (inputSize)) + 384);
	unsigned char* input_copy = (unsigned char*)malloc(sizeof(unsigned char) * inputSize);

	
	
	getData((char*)input, fileName, inputSize);
	printf("\nInput:\t\t\t%s\n", input);
	int outputSize = Huffman_Compress(input, output, (sizeof(unsigned char) * (inputSize)));
	printf("\nOutput:\t\t\t%s", output);
	printf("\nSize of input:\t\t%d", inputSize);
	printf("\nSize of output:\t\t%d\n", outputSize);

	printf("compression ratio:\t%.2f", (float)((float)outputSize / (float)inputSize));

	Huffman_Uncompress(output, input_copy, outputSize, inputSize);
	printf("\nDecompressed string:\t%s\n", input_copy);
}

/*
void DEMOHuffmanAudio() {
	char audio[] = "Recording.dat";
	char compressed[] = "compressed_recording.dat";
	char decompressed[] = "original_file.dat";

	recordAndSave(audio);
	int input_size = GetFileSize(audio);

	unsigned char* input = (unsigned char*)malloc(input_size);
	unsigned char* output = (unsigned char*)malloc(input_size + 384);
	//COMPRESS
	char* input_contents[10000];
	FILE* f;
	fopen_s(&f, audio, "rb");
	fread(input_contents, input_size, 1, f);
	fclose(f);
	int outputSize = Huffman_Compress(input, output, input_size);
	FILE* g;
	fopen_s(&g, compressed, "wb");
	fwrite(output, 1, outputSize, g);
	fclose(g);
	//DECOMPRESS

	FILE* h;
	fopen_s(&h, compressed, "rb");
	fread(output, 1, outputSize, h);
	fclose(h);
	Huffman_Uncompress(output, input, outputSize, input_size);
	FILE* i;
	fopen_s(&i, decompressed, "wb");
	fwrite(input, 1, input_size, i);
	fclose(i);

	printf("\nInput:\t\t\t%d\n", GetFileSize(audio));
	printf("\nOutput:\t\t\t%d\n", GetFileSize(compressed));
	
}

long GetFileSize(const char* filename){
	long size;
	FILE* f;

	fopen_s(&f, filename, "rb");
	if (f == NULL) return -1;
	fseek(f, 0, SEEK_END);
	size = ftell(f);
	fclose(f);

	return size;
}
*/
void DEMOHuffmanAudio() {

	char inputFile[] = "Recording.dat";
	char outputFile[] = "compressed_recording.dat";
	char inputFile_copy[] = "original_file.dat";

	recordAndSave(inputFile);

	int inputSize = getNumChars(inputFile);
	printf("\n\nsize is: %d\n\n", inputSize);

	unsigned char* input = (unsigned char*)malloc(sizeof(unsigned char) * inputSize);
	unsigned char* output = (unsigned char*)malloc((sizeof(unsigned char) * (inputSize)) + 384);
	unsigned char* input_copy = (unsigned char*)malloc(sizeof(unsigned char) * inputSize);

	getData((char*)input, inputFile, inputSize);
	printf("\nInput:\t\t\t%s\n", input);
	int outputSize = Huffman_Compress(input, output, (sizeof(unsigned char) * (inputSize)));

	FILE* write_ptr;	//compressed data
	fopen_s(&write_ptr,outputFile, "wb");
	fwrite(output, sizeof(unsigned char), outputSize, write_ptr);
	fclose(write_ptr);

	//printf("\nOutput:\t\t\t%s", output);
	printf("\nSize of input:\t\t%d", inputSize);
	printf("\nSize of output:\t\t%d\n", outputSize);

	printf("compression ratio:\t%.2f", (float)((float)outputSize / (float)inputSize));

	Huffman_Uncompress(output, input_copy, outputSize, inputSize);
	printf("\nDecompressed string:\t%s\n", input_copy);

	FILE* write_ptr2; //decompressed
	fopen_s(&write_ptr2,inputFile_copy, "wb");
	fwrite(input_copy, sizeof(unsigned char), inputSize, write_ptr2);
	fclose(write_ptr2);

}

/* windowsAudio.cpp -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/

#include "sound.h"
#include "windowsAudio.h"
#include "stdlib.h"
#include "stdio.h"

extern short iBigBuf[];
extern long lBigBufSize;

void recordAndSave(char fileName[]) {
	char save;
	char c;
	//extern short iBigBuf[];					//buffer to store the recorded data into
	//extern long lBigBufSize;				//number of samples used by the audio recording

	InitializeRecording();

	RecordBuffer(iBigBuf, lBigBufSize);
	CloseRecording();

	saveToFile(fileName);
	
}

int saveToFile(char fileName[]) {
	char c;

	FILE* fp;					//file pointer
	fopen_s(&fp, fileName, "wb");
	if (!fp) {
		printf("unable to open file");
		return 1;
	}
	printf("\nWriting to sound file");
	fwrite(iBigBuf, sizeof(short), lBigBufSize, fp);
	printf("\nSize of write %d\n", lBigBufSize);
	fclose(fp);
	printf("\nSound file written! Retruning to menu\n");

	return 0;
}
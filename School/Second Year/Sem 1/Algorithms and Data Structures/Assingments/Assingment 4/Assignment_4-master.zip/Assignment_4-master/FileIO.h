/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/
#include<stdio.h>
#include<stdlib.h>

#define BUFF_SIZE 400


#define canCompress  "can_compress.txt"
#define cantCompress  "cannot_compress.txt"


//fuction prototypes
/*
	void funcName;

	Descriprion goes here!

	Input: None
	Output: None
*/
int getNumChars(const char name[]);

/*
	void funcName;

	Descriprion goes here!

	Input: None
	Output: None
*/
int getData(char outBuff[], const char name[], int size);
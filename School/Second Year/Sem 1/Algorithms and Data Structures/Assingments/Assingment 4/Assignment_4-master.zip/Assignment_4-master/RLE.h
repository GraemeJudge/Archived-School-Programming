/*
	main.cpp: interface for RLE compression / decompression functions
	Author: Stephane Durette
	Copyright 2019
*/

//Prototypes
#define _CRT_SECURE_NO_WARNINGS

int RLECompress(unsigned char* in, int iInLen, unsigned char* out, int iOutLen, unsigned char cESC);
int RLEDecompress(unsigned char* in, int iInLen, unsigned char* out, int iOutLen, unsigned char cESC);

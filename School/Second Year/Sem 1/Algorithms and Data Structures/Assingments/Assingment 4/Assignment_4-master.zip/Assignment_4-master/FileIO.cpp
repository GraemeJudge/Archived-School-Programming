/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/


#include "FileIO.h"


int getNumChars(const char name[]) {
	FILE* fp;
	int count = 0;

	if (fopen_s(&fp, name, "rb") == 0 && fp!=NULL) {
		while (fgetc(fp) != EOF) {
			count++;
		}
	}
	else {
		return 0;
	}
	fclose(fp);
	return count + 1;
}


int getData(char outBuff[], const char name[], int size) {

	FILE* fp;
	char* tempBuffer;
	char c;
	int temp = 0;

	if (fopen_s(&fp, name, "r") == 0 && fp != NULL) {
		for (int i = 0; i < size - 1; i++)
		{
			temp++;
			if ((c = fgetc(fp)) != EOF) {
				outBuff[i] = c;
			}
			else {
				outBuff[i] = '\0';
				break;
			}
		}
		outBuff[size - 1] = '\0';
	}
	else {
		printf("\n\n FILE ERROR \n\n");
		return 1;
	}

	fclose(fp);
	return 0;
}


#include "RLE.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int RLECompress(unsigned char* in, int iInLen, unsigned char* out, int iOutLen, unsigned char cESC) {
	unsigned char c;						//repeated character
	unsigned char output[10];				//temporary buffer with space for the RLE sequence
	out[0] = '\0';							//Enable strcat

	int count;								//Number of repeats
	for (int i = 0; i < iInLen; i++) {
		count = 1;							//start count of a set
		while ((in[i] == in[i + 1]) && (i < iInLen)) {
			c = in[i];
			count++;
			i++;
		}

		//encoding
		if (count >= 3) {
			sprintf((char*)output, "%c%02x%c", cESC, count, c);
			strcat((char*)out, (char*)output);
		}
		else if (count == 2) {
			sprintf((char*)output, "%c%c", in[i], in[i]);
			strcat((char*)out, (char*)output);
		}
		else if (count == 1) {
			sprintf((char*)output, "%c", in[i]);
			strcat((char*)out, (char*)output);
		}
	}
	return (strlen((char*)out));
}
int RLEDecompress(unsigned char* in, int iInLen, unsigned char* out, int iOutLen, unsigned char cESC) {
	int j = 0;
	for (int i = 0; i < iInLen; i++) {
		if (in[i] != cESC) {
			out[j++] = in[i];
		} else {
			char valueString[] = {in[++i], in[++i], '\0'};
			char repeatChar = in[++i];
			int num = (int)strtol(valueString, NULL, 16);
			for (int k = 0; k < num; k++) {
				out[j++] = repeatChar;
			}
		}
	}
	out[j] = '\0';
	return (strlen((char*)out));
}

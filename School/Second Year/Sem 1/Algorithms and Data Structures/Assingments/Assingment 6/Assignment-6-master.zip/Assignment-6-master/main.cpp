#include "Graph.h"
#include <stdlib.h>
#include <stdio.h>

void main() {
	int N = 100;			//Amount of edges in the graph
	int randMin = 2;		//smallest amount of edges that any node can connect to
	int randMax = 6;		//largest amount of edges that any node can connect to
	graph_init(N);			//initialize the graph

	for (int i = 0; i < N; i++) {						//Load items into the graph
		Item temp;
		temp.Random_Data = 1;
		graph_insert_vertex(temp);
	}

	for (int i = 0; i < N; i++) {												//connect nodes to other random nodes (not bidirectional)
		int numEdges = randMin + (rand() % (randMax - randMin + 1)); //random between 2 and 6
		for (int j = 0; j < numEdges; ) {
			int randVertex = rand() % N;
			if (i != randVertex && (graph_is_adjacent(i, randVertex) == 0)) {
				graph_insert_edge(i, randVertex, 1);
				j++;
			}
		}
	}

	for (int i = 0; i < N; i++) {				//print each node and their connections
		printf("Node %d connects to: ", i);
		for (int j = 0; j < N;j++) {
			if (graph_is_adjacent(i, j) > 0) {
				printf(" %d", j);
			}
		}
		printf("\n");
	}
	system("pause");
}
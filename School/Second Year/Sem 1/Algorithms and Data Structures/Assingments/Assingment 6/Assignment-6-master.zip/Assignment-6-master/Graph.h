

typedef struct item {								//Placeholder Struct
	int Random_Data;
} Item;

void graph_init(int NodeCount);						//Create the adjacency matrix and list of elements
int graph_insert_vertex(Item data);					//insert a new item into the item list
int graph_insert_edge(int v1, int v2, int weight);	//insert a new connection between the item at the v1th index and the item at the v2'th index
int graph_is_adjacent(int v1, int v2);				//Check the connection between item at v1 and item at v2
int get_graph_vertexCount();						//get the amount of vertices in the graph
#include "Graph.h"
#include "stdlib.h"

//list of connections with their weights
static int** AdjacencyMatrix;

//amount of items stored in the nodes
static int vertexCount;

//List of items 
static Item* Items;

void graph_init(int MaxVertexCount) {
	int vertexCount = 0;

	Items = (Item*)calloc(MaxVertexCount, sizeof(Item));				//Allocate space for N items

	AdjacencyMatrix = (int**)calloc(MaxVertexCount, sizeof(int*));		//allocates space for an N x N adjacency matrix
	for (int i = 0; i < MaxVertexCount; i++) {
		AdjacencyMatrix[i] = (int*)calloc(MaxVertexCount, sizeof(int));
	}
}

int graph_insert_vertex(Item data) {		//insert an item into the list of items
	Items[vertexCount++] = data;
	return 0;
}

int get_graph_vertexCount() {
	return vertexCount;
}

int graph_insert_edge(int v1, int v2, int weight) {
	AdjacencyMatrix[v1][v2] = weight;
	return 0;
}
int graph_is_adjacent(int v1, int v2) {
	return AdjacencyMatrix[v1][v2];
}
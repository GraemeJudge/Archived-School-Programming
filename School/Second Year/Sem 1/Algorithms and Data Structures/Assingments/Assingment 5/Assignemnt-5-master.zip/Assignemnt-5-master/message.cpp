/* Implementation: Functions for File IO - Getting random messages from a file
*  By: Stephane Durette, Graeme Judge, Rushi Patil
*/

#pragma warning (disable: 6386)
#pragma warning (disable: 6011)

#include "message.h"
static int numQuotes;
static long int* quoteIndices;
static int* quoteLengths;

int frandNum(int min, int max) {
	return(min + (rand() % (max - min + 1)));
}

void InitMessages() {
	numQuotes = fnumQuotes();
	quoteIndices = fquoteIndices(numQuotes);
	quoteLengths = fquoteLength(numQuotes, quoteIndices);
}

int fnumQuotes(void) {

	FILE* fp;
	char c;
	int counter = 0;

	if (fopen_s(&fp, "FortuneCookies.txt", "r") == 0 && fp != NULL) {

		while ((c = fgetc(fp)) != EOF) {
			if (c == '%' && fgetc(fp) == '%') {
				counter++;
			}
		}

		fclose(fp);
		return(counter);
	}
	else {
		printf("\nFile failed to open");
		return(1);
	}
	return(0);
}


long int* fquoteIndices(int numQuotes) {

	int* indices = (int*)malloc(numQuotes * sizeof(long int));

	FILE* fp;
	char c;
	int index = 0;

	if (fopen_s(&fp, "FortuneCookies.txt", "r") == 0 && indices != NULL && fp != NULL) {

		while ((c = fgetc(fp)) != EOF) {
			if (c == '%' && fgetc(fp) == '%') {
				indices[index] = ftell(fp);
				index++;
			}
		}
		fclose(fp);
		return((long int*)indices);
	}
	else {
		printf("\nFile failed to open\n");
		return(NULL);
	}
}


int* fquoteLength(int numQuotes, long int* quoteIndices) {
	int* quoteLengths = (int*)malloc(sizeof(int) * (numQuotes));

	int lineCount = 0;

	int finalQuoteLength = 0;



	FILE* fp;

	for (int i = 0; i < numQuotes - 1; i++)
	{
		quoteLengths[i] = ((quoteIndices[i + 1] - quoteIndices[i]));
	}

	if (fopen_s(&fp, "FortuneCookies.txt", "r") == 0 && fp != NULL) {
		fseek(fp, quoteIndices[numQuotes - 1], 0);
		while (fgetc(fp) != EOF) {
			finalQuoteLength++;
		}
		fclose(fp);
	}
	if (finalQuoteLength != NULL) {
		quoteLengths[numQuotes - 1] = finalQuoteLength;
	}

	return quoteLengths;
}
//
int GetMessage(char szBuf[], int iLen, int index) {
	if (index >= numQuotes) return 1;
	char c;
	int clear = 0;

	FILE* fp;

	if (fopen_s(&fp, "FortuneCookies.txt", "r") == 0 && fp != NULL) {
		fseek(fp, quoteIndices[index], SEEK_SET);
		int i;
		int maxLen = quoteLengths[index] < iLen - 1 ? quoteLengths[index] : iLen - 1; //Takes min between the length of the quote and iLen
		for (i = 0; i < maxLen; i++) {
			c = fgetc(fp);
			if (c != '%' && clear < 1) {
				szBuf[i] = c;
			}
			else {
				szBuf[i] = ' ';
				clear++;
			}
		}
		szBuf[i] = '\0';
	}
	else {
		return 1;
	}
	fclose(fp);

	return 0;
}
//// Function that gets a random quote from the FortuneCookies file 
int GetRandomMessageFromFile(char szBuf[], int iLen) {
	//int numQuotes = fnumQuotes();
	int randi = frandNum(0, numQuotes);
	//long int* quoteIndices = fquoteIndices(numQuotes);
	//int* quoteLengths = fquoteLength(numQuotes, quoteIndices);
	return GetMessage(szBuf, iLen, randi);
}
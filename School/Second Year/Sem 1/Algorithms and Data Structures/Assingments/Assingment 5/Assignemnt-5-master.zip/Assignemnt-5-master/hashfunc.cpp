#include "hashfunc.h"
#include <stdlib.h>
#include <stdio.h>

static int size;
static int M;
static int* iMsgList;
static int* iHashTab;


void InitHashTable(int _size, int _M) {
	size = _size;
	M = _M;
	iMsgList = (int*)calloc(size, sizeof(int));
	for (int i = 0; i < size; i++) { iMsgList[i] = -1; }

	iHashTab = (int*)calloc(M, sizeof(int));
	for (int i = 0; i < M; i++) { iHashTab[i] = -1; }
}

void InsertHash(char message[140], int n) {
	int k = hashU(message, M);
	if (iHashTab[k] == -1) {
		iHashTab[k] = n;
	} else {
		iMsgList[n] = iHashTab[k];
		iHashTab[k] = n;
	}
}

void PrintCollisions() {
	for (int i = 0; i < M; i++) {
		printf("Hash key %d:\tMessage Numbers:", i);
		int mNumber = iHashTab[i];
		while (mNumber != -1) {
			printf("\t%d", mNumber);
			mNumber = iMsgList[mNumber];
		}
		printf("\n");
	}
}

int hashU(char* v, int _M) {
	int h, a = 31415, b = 27183;
	for (h = 0; *v != '\0'; v++) {
		a = (a * b) % (_M - 1);
		h = (h * a + *v) % _M;
	}
	return abs(h);
}
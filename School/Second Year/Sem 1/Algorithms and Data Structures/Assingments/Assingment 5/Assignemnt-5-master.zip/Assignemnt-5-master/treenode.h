/*
	treenode.h - Header file that contains the node structure of a BST
	Copyright 2019 Stephane Durette
*/
#pragma once
#define _CRT_SECURE_NO_WARNINGS
const int iLength = 140;

//Define the structure of nodes in a BST

typedef struct BSTNode* link;
typedef struct item Item;
typedef struct BSTNode Node;

//Define the Item - content of the BST nodes
struct item {
	char buff[iLength];
	int hashKey;
};

struct BSTNode {
	Item msg;			//message item
	link pLeft;			//left subtree
	link pRight;		//right subtree
};

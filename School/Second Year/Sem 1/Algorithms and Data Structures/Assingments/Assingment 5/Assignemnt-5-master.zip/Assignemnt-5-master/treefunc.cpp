/*
	treefunc.cpp - Implementation of BST
	Copyright 2019 Stephane Durette
*/

#include "treefunc.h"
#include "treenode.h"
#include <stdio.h>;
#include <stdlib.h>;
#include <string.h>;
#define NULL 0

//Private variables
static link root;				//root of the BST
static Item NullItem = {"NOT FOUND - NULL (LEAF) Reached"};	//indicate that a searched message has not been found

//Function implementations


link NEW(Item item, link left, link right) {
	link pNew = (link)malloc(sizeof(Node));
	pNew->msg = item;
	pNew->pLeft = left;
	pNew->pRight = right;
	return pNew;
}

void BSTInit(void) {
	root = NEW(NullItem, NULL, NULL);
}

Item BSTsearch(link h, char* szKey) {
	if (h == NULL) return(NullItem);		//terminal condition - reached leaf node and did not find szSearchKey
	int rc = strcmp(szKey, h->msg.buff);

	if (rc == 0)	return h->msg;
	if (rc > 0)		return (BSTsearch(h->pRight, szKey));
	else			return (BSTsearch(h->pLeft, szKey));
}

Item Search(char* szKey) {
	return(BSTsearch(root, szKey));
}

link BSTInsert(link h, Item item) {
	if (h == NULL) return(NEW(item, NULL, NULL));		//terminal condition - reached leaf node and did not find szSearchKey
	//int rc = strcmp(item.buff, h->msg.buff);
	//printf("Key 1: %d,       Key 2: %d\n", item.hashKey, h->msg.hashKey);
	if ((item.hashKey) > (h->msg.hashKey)) {
		h->pRight = BSTInsert(h->pRight, item);
	} else {
		h->pLeft = BSTInsert(h->pLeft, item);
	}

	return h;
}


void Insert(Item item) {
	BSTInsert(root, item);
}

void BSTPrint(link h) {
	if (h == NULL) return;
	BSTPrint(h->pLeft);
	printf("\nMessage: %s\n", h->msg.buff);
	BSTPrint(h->pRight);
}

int height(link h) {
	if (h == NULL) return -1;
	
	int iLeftH = height(h->pLeft);
	int iRightH = height(h->pRight);
	if (iLeftH > iRightH) return iLeftH + 1;
	else return iRightH + 1;
}

int count(link h) {
	if (h == NULL) return 0;

	return(count(h->pLeft) + count(h->pRight) + 1);
}

link getRoot(void) {
	return root;
}

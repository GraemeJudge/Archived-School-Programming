/* Message.h

   This is a header file that contains the definitions for
   all the functions and structures
   implemented by message.cpp

	Authors: Stephane Durette, Graeme Judge, Rushi Patil
	Date: October 8, 2019
	Change Log:
		Oct 8, 2019 - Source file created
*/

#pragma once
/*
	Header files needed
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>


void InitMessages();
//Function Definitions

/*
	int frandNum(int min, int max);

	This function returns a random integer number
	between min and max.

	Input: int min
			Minimum value that can be returned
	Input: int max
			Maximum value that can be returned
	Returns:
			A random integer value between min and max
*/
int frandNum(int min, int max);

/*
	int fnumQuotes(void);

	This function returns the number of quotes contained in the
	file "FortuneCookies.txt". Every Quote is preceeded by the
	Characters "%%". It traverses the file and counts the amount of
	These characters.

	Input:
		Nothing

	Returns:
			1 if there is an error
			0 if there is no error
*/
int fnumQuotes(void);

/*
	long int* fquoteIndices(int numQuotes);

	This function traverses the file and stores each quote starting location
	in an integer array that is returned to the user.

	Input: int numQuotes
			The number of quotes in the file

	Returns: long int*
			an array of indices that represent where each quote begins in
			the file
*/
long int* fquoteIndices(int numQuotes);

/*
	int* fquoteLength(int numQuotes, long int* quoteIndices);

	This function takes in a number of quotes and indices. It
	calculates the length of each quote based on the distance between their
	starting location in the file. It then gets the last quote length by checking
	its distance from the end of the file. It returns an integer array that represents
	the length of each quote in characters.

	Input: int numQuotes
			The number of quotes in the file

	Input: long int* quoteIndices
			An array that represents the starting location of each quote

	Returns: long int*
			an array of the lengths of each quote
*/
int* fquoteLength(int numQuotes, long int* quoteIndices);

/*
	int GetMessageFromFile(char szBuf[], int iLen);

	This function uses all the above functions to return a random quote from the file.
	It receives a random number from frandNum(int min, int max). it then counts the amount of
	quotes from the file, calculates their length and their starting location in the file.
	It finds a quote from a random index in the file and places it in the buffer szBuf. It also
	Truncates the quote to 140 characters (including the null terminator).

	Input: char szBuf[]
			the buffer passed by reference that the random quote will be stored in.
	Input: int iLen
			Size of the buffer in bytes
	Output:
			1 if there's a file error
			0 if there's no file error
*/
int GetRandomMessageFromFile(char szBuf[], int iLen);
int GetMessage(char szBuf[], int iLen, int index);

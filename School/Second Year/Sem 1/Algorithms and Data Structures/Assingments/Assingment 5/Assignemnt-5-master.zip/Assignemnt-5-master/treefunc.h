/*
	treefunc.h - Header file that contains the function prototypes for a BST
	Copyright 2019 Stephane Durette
*/
#define _CRT_SECURE_NO_WARNINGS
#include "treenode.h"

//function prototypes
link NEW(Item item, link left, link right);		//creates a new BST node
void BSTInit(void);								//initialize the BST
Item BSTsearch(link h, char* szSearchKey);		//private search function called by "Search()"
Item Search(char* szKey);						//public search function
link BSTInsert(link h, Item item);				//private insert function called by "Insert()"
void Insert(Item item);						//public search function
void BSTPrint(link h);							//Private print function 
int height(link h);								//returns the height of the tree
int count(link h);								//returns the number of nodes in the tree
link getRoot(void);								//returns a pointer to the root of the BST


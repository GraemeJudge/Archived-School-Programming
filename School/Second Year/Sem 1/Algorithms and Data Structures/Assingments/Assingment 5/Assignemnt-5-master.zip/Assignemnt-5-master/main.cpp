#include "message.h"
#include "hashfunc.h"
#include "treefunc.h"
#include "treenode.h"

#define MAX_LENGTH 140

void PartA();
void PartB();

void main() {
	//PartA();
	PartB();
}

void PartA() {
	InitMessages();
	BSTInit();

	int M = 29;
	int numQuotes = 110;
	numQuotes = (numQuotes < fnumQuotes()) ? numQuotes : fnumQuotes(); //min between numquotes and fnumquotes
	int* keyCounts = (int*)calloc(M, sizeof(int));
	int collisions = 0;

	for (int i = 0; i < numQuotes; i++) {
		Item new_item;
		GetMessage(new_item.buff, MAX_LENGTH, i);
		new_item.hashKey = hashU(new_item.buff, M);

		if ((++keyCounts[new_item.hashKey]) > 1) { collisions++; }
		Insert(new_item);
	}
	printf("*** HashKeys ***\n");
	for (int i = 0; i < M; i++) {
		printf("%d:\t\t%d\n", i, keyCounts[i]);
	}
	printf("Number of collisions:\t\t%d\n", collisions);
	printf("Count of tree %d\n", count(getRoot()));
	printf("Height of tree %d\n", height(getRoot()));
}

void PartB() {
	int sz = 110;
	int M = 29;
	InitHashTable(sz, M);
	for (int i = 0; i < sz; i++) {
		char msg_buffer[MAX_LENGTH];
		GetMessage(msg_buffer, MAX_LENGTH, i);
		InsertHash(msg_buffer, i);
	}
	PrintCollisions();
	

}
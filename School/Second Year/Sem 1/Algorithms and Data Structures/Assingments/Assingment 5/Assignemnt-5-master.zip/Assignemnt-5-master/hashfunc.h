int hashU(char* v, int M);
void InitHashTable(int _size, int _M);
void InsertHash(char message[140], int n);
void PrintCollisions();
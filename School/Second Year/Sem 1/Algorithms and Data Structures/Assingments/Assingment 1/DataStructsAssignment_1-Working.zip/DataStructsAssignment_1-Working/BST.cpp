/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/

#include <math.h> 
#include "BST.h"

static message nullItem = {};
static tLink treeRoot;


tLink NEW(message item, tLink left, tLink right) {
	tLink pNew = (tLink)malloc(sizeof(*pNew));
	pNew->item = item;
	pNew->pLeft = left;
	pNew->pRight = right;
	return(pNew);
}

void initBST() {
	treeRoot = NEW(nullItem, NULL, NULL);		//Starts the tree empty
}


message BSTSearch(tLink h, char *szKey) {
	int compare;
	if (h == NULL) {							//reached the end of the tree without finiding it
		return(nullItem);
	}
	compare = strcmp(szKey, h->item.message);
	if (compare == 1) {							//it matched
		return h->item;
	}
	if (compare < 0) {								//it didnt match
		return(BSTSearch(h->pLeft, szKey));
	}
	else {
		return BSTSearch(h->pRight, szKey);
	}

}

message search(char* szKey) {
	return(BSTSearch(treeRoot, szKey));
}

void print() {
	BSTPrint(treeRoot);
}

void BSTPrint(tLink h) {
	if (h == NULL) {
		return;
	}
	BSTPrint(h->pLeft);
	printf("\n%s\n-------------------", h->item.message);
	BSTPrint(h->pRight);
};


tLink BSTInsert(tLink h, message item) {
	int compare;
	if (h == NULL) {
		return (NEW(item, NULL, NULL));
	}
	compare = strcmp(item.message, h->item.message);
	if (compare < 0) {
		h->pLeft = BSTInsert(h->pLeft, item);
	}
	else {
		h->pRight = BSTInsert(h->pRight, item);
	}

	return h;
}


void insert(message item) {
	BSTInsert(treeRoot, item);
}

//generally it sould start counting at the root (so startCountAt SHOULD be the root)
int BSTCountNodes(tLink startCountAt) {
	if (startCountAt == NULL) return 0;

	return(BSTCountNodes(startCountAt->pLeft) + BSTCountNodes(startCountAt->pRight) + 1);
}

int countNodes() {
	return(BSTCountNodes(treeRoot));
}

int getHeight() {
	return(BSTgetHeight(treeRoot)); 
	//return(floor(log2(BSTCountNodes(treeRoot)))); //if the bst is balanced
}

int BSTgetHeight(tLink rootOfHeight) {
	if (rootOfHeight == NULL)
	{
		return -1; 
	}
	else
	{
		int leftH = (BSTgetHeight(rootOfHeight->pLeft) + 1); 
		int rightH = (BSTgetHeight(rootOfHeight->pRight) + 1); 

		return((leftH > rightH)?leftH:rightH); 
	}

}

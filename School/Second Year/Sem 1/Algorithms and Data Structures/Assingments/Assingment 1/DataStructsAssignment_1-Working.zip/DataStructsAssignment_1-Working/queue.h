/* Queue.h

   This is a header file that contains the definitions for
   all the functions and structures
   implemented by queue.cpp

	Authors: Stephane Durette, Graeme Judge, Rushi Patil
	Date: October 8, 2019
	Change Log:
		Oct 8, 2019 - Source file created
*/

#pragma once
/*
	Header files needed
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "message.h"


//Structures
typedef struct node NODE;
typedef struct node* link;


struct node {						//Nodes to be used in the queue holding the message and the next node pointer
	link pNext;
	MESSAGE data;
};

//Function Prototypes
/*
	void InitQueue( void );

	Initializes the queue by setting the head and tail node* to null;

	Input: None
	Output: None
*/
void InitQueue(void);

/*
	void Push(NODE* node);

	appends a node* object to the queue.

	Input: NODE* node
			the node object to append to the queue.
	Output: None
*/
void Push(NODE* node);

/*
	NODE *Pop( void );

	returns the first item in the queue and removes it from the linked list.

	Input: None
	Output: Node* that was popped off the linked list
*/
NODE* Pop(void);

/*
	int IsQueueEmpty( void );

	Checks if the queue is empty

	Input: None
	Output:
		1 if the queue is empty
		0 if the queue is not empty
*/
int IsQueueEmpty(void);

/*
	void PrintContents();

	Prints all of the messages in the queue in order

	Input: None
	Output None
*/
void PrintContents();


/*
	void PrintMessage();

	Prints the message of a given node

	Input: link h 
			The pointer to the node whose message is to be printed
	Output None
*/
void PrintMessage(link h);

//new stuff for assignment 2

/*
	void traverse(link h, void(*f)(link h));

	This function recusively traverses through the queue. Calls a function f
	with the current link as an argument and calls itself with the next link.
	This stops when the current link is null.

	Input: link h
			a pointer to the head node of the queue
	Input: void(*f)(link h)
			a pointer to a function that takes a node* as an argument
*/
void traverse(link h, void (*f)(link h));

/*
	void traverseR(link h, void(*f)(link h));

	This function does exactly what traverse does except it
	calls itself before calling the function. Which causes the function 
	calls to happen in reverse order which simulates a backward traversal 
	through the list

	Input: link h
			a pointer to the head node of the queue
	Input: void(*f)(link h)
			a pointer to a function that takes a node* as an argument
*/
void traverseR(link h, void (*f)(link h));

/*
	link getHead();

	This function returns a pointer to the first node in the queue.

	Input: None
	Output: node* representing the first node in the queue.
*/
link getHead();

/*
	link deleteR(link parent, link child, MESSAGE v);

	This function deletes all nodes in a queue where the senderid is equal to
	v's sending id.

	Input: link parent
			the link before the link being checked
	Input: link child
			the link being checked
	Input: MESSAGE v
			if the node contains this message, it must be removed from the queue.

	Output: None
*/
link deleteR(link parent, link child, MESSAGE v);



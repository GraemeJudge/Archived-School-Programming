/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/

#include "message.h"

typedef struct BSTNode* tLink;

struct BSTNode {
	message item;
	tLink pLeft;
	tLink pRight;
};

/*
	tLink NEW(message item, tLink left, tLink right);

	A helper function that creates a new node for the tree with a given 
	message left child and right child

	Input: message item
		message item to be placed in the tree
	Input: tLink left
		left child of the node
	Input: tLink right
		right child of the node
*/
tLink NEW(message item, tLink left, tLink right);

/*
	void initBST();

	creates a new binary search tree with an empty node
	at the root.

	Input: None
	Output: None
*/
void initBST(void);

/*
	void BSTInsert(message item, tLink h);

	recursive function that compares the two messages and places them in order
	in the binary search tree

	Input: message item
		message to be inserted
	Input: tLink h
		current node
	Output: None
*/
void BSTInsert(message item, tLink h);

/*
	void insert(message item);

	calls BSTInsert and passes in an item with the root node 
	as an argument.

	Input: message item
		message to be inserted
	Output: None
*/
void insert(message item);

message BSTSearch(tLink h, char *szKey);
message search(char *szKey);

/*
	void print();

	calls BSTPrint and passes in a link to the root node
	as an argument.

	Input: None
	Output: None
*/
void print();

/*
	void BSTPrint(tLink h);

	recursively traverses the tree inorder and prints all the messages in 
	alphabetical order

	Input: tLink
		link to the current node in the tree
	Output: None
*/
void BSTPrint(tLink h);

/*
	void BSTCountNodes(tLink h);

	recursively counts all the nodes in a tree.

	Input: tLink
		link to the current node in the tree
	Output: None
*/
int BSTCountNodes(tLink startCountAt); 

/*
	int countNodes();

	calls BSTCountNodes and passes in a link to the root node
	as an argument.

	Input: None
	Output: number of nodes in the tree
*/
int countNodes();

/*
	int getHeight();

	calls BSTgetHeight and passes in a link to the root node
	as an argument.

	Input: None
	Output: height of the tree
*/
int getHeight();

/*
	int BSTgetHeight(tLink rootOfHeight);

	recursively traverses the tree and counts the height of each subtree.

	Input: None
	Output: height of the subtree
*/
int BSTgetHeight(tLink rootOfHeight); 






/* main.cpp - Main file for testing the File IO functions that get random messages from a file 
*  By: Michael Galle
*  Modified By: Graeme Judge, Stephane Durette, Ruchi Patil
*/

#pragma warning (disable: 6031)
#pragma warning (disable: 6011)

#include "message.h"
#include "queue.h"
#include "BST.h";

//Function prototypes
void part1Main();
void part2Main(int numToGet);
void assignment2(int numToGet);
void assignment3(int numToGet);



/*
	void main();

	main function of the program that will run assignment part 1 or 2 based on the 
	command line arguements passed in 
	the first command line arguement is to define which assignemnt part to run
	The second command line arguement is to define how many quotes to get and 
	push to the queue (assignment part 2 only)


*/
int main(int argc, char** argv) {
	int firstArg = atoi(argv[1]);	//Which assignment part to run
	int secondArg = atoi(argv[2]);	//How many quotes to get if its assignment part 2

	if (firstArg == 1) {			//Run part 1
		part1Main();
	}else if (firstArg == 2) {		//Run part 2
		if (argc != 3) {			//Make sure the number of quotes is defined
			printf("Please pass in the amount of quotes as an integer");
			return 1;				//Returns 1 if the number of quotes to get wasn't defined
		}
		else {						
			part2Main(secondArg);	
		}
	}
	else if (firstArg == 3) {
		if (argc != 3) {			//Make sure the number of quotes is defined
			printf("Please pass in the amount of quotes as an integer");
			return 1;				//Returns 1 if the number of quotes to get wasn't defined
		}
		else {
			assignment2(secondArg);
		}
	}
	else if (firstArg == 4) {
		if (argc != 3) {			//Make sure the number of quotes is defined
			printf("Please pass in the amount of quotes as an integer");
			return 1;				//Returns 1 if the number of quotes to get wasn't defined
		}
		else {
			assignment3(secondArg);
		}

	}
	else {
		return(1);					//Returns 1 if the requested assignment part was undefined
	}

	return(0);						//Returns 0 on normal execution with no errors
}


/*
	void part1Main();

	This function tests the GetMessageFromFile function by getting 
	25 random quotes from the file (assignment part 1)

*/
void part1Main() {

	srand((int)time(NULL));
	char message[MAX_QUOTE_LENGTH];
	for (int i = 0; i < 25; i++) {
		GetMessageFromFile(message, MAX_QUOTE_LENGTH);
		printf("%s [Length: %d]\n\n,", message, (int)strlen(message));

	}

	getchar();					//Holds the window open until a key press so you can view the messages
	
}


/*
	void part2Main(int numToGet);

	This function gets the specified number of quotes from the file and pushes them
	onto the queue then pops them off and prints them after the loops executes getting
	the number of quotes (assignment part 2)

	Input: int numToGet
			The number of quotes to get
*/
void part2Main(int numToGet) {

	InitQueue();					// initialize the queue
	int N = numToGet;				//How many quotes to get from the file and put into the queue
	srand((int)time(NULL));

	for (int i = 0; i < N; i++) {	//Gets the random message and puts it into the queue
		NODE* newNode = (link)malloc(sizeof(NODE));
		MESSAGE newMessage = { "",0,0,0,0,{0} };
		GetMessageFromFile(newMessage.message, MAX_QUOTE_LENGTH);
		newNode->data = newMessage;
		Push(newNode);
		}
	int i = 1;
	while (!IsQueueEmpty()) {	//Runs until the queue is empty
		char* message = Pop()->data.message;
		printf("-----Message %d:-----\n%s\n\nSize of Message: %d characters\n\n", i, message, (int)strlen(message));
		i++;
	}

	getchar();					//Holds the window open until a key press so you can view the messages

}



/*
	void assignment2(int numToGet);

	This function gets the specified number of quotes from the file and pushes them
	onto the queue then then traverses through the queue recursively forwards printing each 
	then repeats the process to recursively traverse the queue in reverse printing each message

	Input: int numToGet
			The number of quotes to get
*/
void assignment2(int numToGet) {
	InitQueue();					// initialize the queue
	int N = numToGet;				//How many quotes to get from the file and put into the queue
	srand((int)time(NULL));

	for (int i = 0; i < N; i++) {	//Gets the random message and puts it into the queue
		NODE* newNode = (link)malloc(sizeof(NODE));
		GetMessageFromFile(newNode->data.message, MAX_QUOTE_LENGTH);
		Push(newNode);

		//printf("\nLoaded message number %d into queue with message: \n%s\n", i, newMessage.message);
	}
	//need a reference to the head node for traversal
	link head = getHead();

	//traversing forward
	printf("\n\n ******************************** \n\n");
	printf("\nForward traverse: \n");
	traverse(head, PrintMessage);

	//traversing reverse
	printf("\n\n ******************************** \n\n");
	printf("\nReverse traverse: \n");
	traverseR(head, PrintMessage);
}


void assignment3(int numToGet) {
	initBST();
	srand((int)time(NULL));
	for (int i = 0; i < numToGet; i++)
	{
		MESSAGE newMessage = { "",0,0,0,0,{0} };
		GetMessageFromFile(newMessage.message, MAX_QUOTE_LENGTH);
		insert(newMessage);
	}
	int height = getHeight();
	printf("\nHeight of the tree: %d\n", height);

	int numberOfNodes = countNodes();
	printf("\nnumber of nodes in the tree: %d\n", numberOfNodes);

	print();

}

#pragma once
void DisplaySettingsMenu();

void ChangeBitrate();

void ChangeRecordTime();

void ChangeSampleRate();
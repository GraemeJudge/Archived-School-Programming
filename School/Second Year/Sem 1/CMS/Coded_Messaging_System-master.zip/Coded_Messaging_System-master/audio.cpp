/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/

#include "sound.h"
#include "queue.h"
#include "menu.h"
#include "audio.h"
#include "settings.h"

static MenuChoice options[] = {
	{"Record and Playback Demo", &recordAndPlay},
	{"Play Audio From File", &playFromFile},
	{"Change Settings", &DisplaySettingsMenu},
	{"Back to main menu", &DisplayMenu},
	{"Exit", &exit}
};

void DisplayAudioMenu() {
	char title[] = "Audio Menu";
	int n = sizeof(options) / sizeof(MenuChoice);
	DisplayTempMenu(title, options, n);
}

void ChangeSettings() {
	//settings stuff 
		//save and load file location and file name
		//length of recording ();
	printf("changing the settings");
	NotImplemented();
	DisplayAudioMenu();
}

void recordAndPlay() {
	char save;
	char c;
	extern short iBigBuf[];					//buffer to store the recorded data into
	extern long lBigBufSize;				//number of samples used by the audio recording


	InitializePlayback();
	InitializeRecording();

	//record sound
	RecordBuffer(iBigBuf, lBigBufSize);
	CloseRecording();

	//playback from buffer
	printf("\nStarting audio playback from buffer\n");
	PlayBuffer(iBigBuf, lBigBufSize);
	ClosePlayback();

	printf("\nWould you like to save the audio recording to a file? (y/n): ");
	scanf_s("%c", &save, 1);
	while ((c = getchar()) != '\n' && c != EOF) {}										//clears input buffers before moving to the next step
	if ((save == 'y') || (save == 'Y')) {
		saveToFile(iBigBuf, lBigBufSize);
	}else{
		printf("\nAudio not being saved, returning to menu\n");
	}
	DisplayAudioMenu();
}



int saveToFile(short *iBigBuf, long lBigBufSize) {
	char c;

	FILE* fp;					//file pointer
			fopen_s(&fp, "C:\\Users\\Graeme Judge\\Desktop\\Recording.dat", "wb"); //need the file pointer still
			if (!fp) {
				printf("unable to open file");
				return 1;
			}
			printf("\nWriting to sound file");
			fwrite(iBigBuf, sizeof(short), lBigBufSize, fp);
			fclose(fp);
			printf("\nSound file written! Retruning to menu\n");

	return 0;
}

void playFromFile() {
	char replay;
	char c;

	int audioLength;

	extern long lBigBufSize;				//number of samples used by the audio recording
	short* loadBuffer = (short*)malloc(lBigBufSize * sizeof(short));		// buffer used for reading recorded sound from file

	FILE* fp;
	
	printf("\nWould you like to read the audio file?(y/n) ");
	scanf_s("%c", &replay, 1);

	// replay audio recording from file -- read and store in buffer, then use playback() to play it
	while ((c = getchar()) != '\n' && c != EOF) {}								// Flush other input
	if ((replay == 'y') || (replay == 'Y')) {
		/* Open input file */
		fopen_s(&fp, "C:\\Users\\Graeme Judge\\Desktop\\Recording.dat", "rb");
		if (!fp) {
			printf("unable to open %s\n", "C:\\Users\\Graeme Judge\\Desktop\\Recording.dat");
		}

		audioLength = getAudioLength(fp);

		printf("audio length: %d\n",audioLength);



		printf("Reading from sound file ...\n");
		fread(loadBuffer, sizeof(short), audioLength * SAMPLES_SEC, fp);				// Record to new buffer iBigBufNew
		fclose(fp);
		printf("\nPlaying recorded audio from saved file ...\n");
		InitializePlayback();
		PlayBuffer(loadBuffer, audioLength * SAMPLES_SEC);
		ClosePlayback();

		printf("\nFinished playing audio from saved file! Retruning to menu\n");
	}
	else {
		printf("\nOkay no audio will be played! Retruning to the menu\n");
	}
	DisplayAudioMenu();
}


int getAudioLength(FILE* fp) {
	int size;
	fseek(fp, 0, SEEK_END); // seek to end of file
	size = ftell(fp);
	fseek(fp, 0, SEEK_SET);


	return(size/(SAMPLES_SEC * sizeof(short)));
}
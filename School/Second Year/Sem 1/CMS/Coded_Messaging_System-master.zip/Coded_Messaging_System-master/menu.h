/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/


//Structs
typedef struct mc MenuChoice;


//function prototypes
void DisplayMenu();
void DisplayTempMenu(char title[], MenuChoice* options, int size);
void NotImplemented();
void exit();


//struct definitions
struct mc {
	char name[140];
	void (*action)(void);
};

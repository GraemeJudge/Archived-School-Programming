#pragma once
/* encdec.h
Stephane, Graeme, Ruchi 
*/


#ifndef ENCDEC_H 
#define ENCDEC_H  

char* encrypt(char* message, char* key);

#endif // !ENCDEC_H 
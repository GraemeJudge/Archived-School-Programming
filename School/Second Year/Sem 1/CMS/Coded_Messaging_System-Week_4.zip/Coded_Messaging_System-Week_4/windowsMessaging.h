/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/

#include <Windows.h>
#include <stdio.h>

// Prototype the functions to be used

void sendRandomFortune();
void sendMessage();
void recieveMessage();
void initSendPort();
void initRecievePort();
void purgePort();
void outputToPort(LPCVOID buf, DWORD szBuf);
void inputFromPort(LPVOID buf, DWORD szBuf);

void DisplayMessagingMenu();

// Sub functions
void createSendPortFile();
void createRecievePortFile();
static int SetComParms();




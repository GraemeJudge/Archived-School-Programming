/* encdec.cpp - dencryption and decryption
Stephane, Graeme, Ruchi 
*/


#include <stdlib.h> 
#include <string.h>
#include <stdio.h>
#include "encdec.h"


char* encrypt(char* message, char* key) {
	int size_message = strlen(message);
	int size_key = strlen(key);
	char* code = (char*)malloc((size_message + 1) * sizeof(char)); //initialize array of same size as message to be coded

	for (int i = 0; i < size_message; i++)
	{
		code[i] = key[i % size_key] ^ message[i];
	}
	code[size_message] = '\0';

	return code;
}


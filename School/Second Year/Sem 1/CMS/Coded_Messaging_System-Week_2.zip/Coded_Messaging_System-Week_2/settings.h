#pragma once
void DisplayMessagingSettingsMenu();

void DisplayAudioSettingsMenu();


void ChangeRecordTime();

void ChangeSampleRate();
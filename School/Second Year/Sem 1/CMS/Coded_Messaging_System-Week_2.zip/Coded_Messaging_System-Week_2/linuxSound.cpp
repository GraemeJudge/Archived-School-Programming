/* stream.cpp : Implementation functions for playback / capture of streams
 *
 * Copyright 2019 Michael Galle
 */
#if defined(__linux__)
#include <stdio.h>
#include <alsa/asoundlib.h>		// At terminal need to install alsa headers to /usr/include/alsa via installing: $ sudo apt-get install libasound2-dev   
#include "linuxSound.h"
#include <math.h>

int prepareStream(snd_pcm_t** pcm_handle, snd_pcm_stream_t stream, snd_pcm_hw_params_t** hwparams, char* pcm_name) {
	// Variables
	unsigned int exact_rate;			// Sample rate near requested that the system is capable of: using snd_pcm_hw_params_set_rate_near()
	snd_pcm_uframes_t exact_frames;		// If the buffer (max size is 16384 frames [16384 * 4 bytes]) cannot support the number of frames desired in 'frames', a function below changes this value to 'exact_frames' supported
	int dir;							// if exact_rate == rate then dir = 0, if exact_rate < rate then dir = -1, if exact_rate > rate then dir = 1

	int BYTES_PER_FRAME = (NUM_CHANNELS * BYTES_PER_SAMPLE);      		// = 4 for 16 bit stereo, = 2 for 16 bit mono
	int FRAMES_PER_HW_BUF = (BYTES_PER_HW_BUF / BYTES_PER_FRAME);    	// Number of frames in a completely full hardware buffer

	// Allocate space for the hwparams structure on the stack
	snd_pcm_hw_params_alloca(hwparams);

	// Open the PCM device (for playback)
	if (snd_pcm_open(pcm_handle, pcm_name, stream, stream) < 0) {
		fprintf(stderr, "Error opening PCM device %s\n", pcm_name);
		return(-1); // Fail
	}

	// Specify the control parameters of the PCM device 
	// (access type, buffer size, # of channels, sample format, sample rate, number of periods, etc)
	// First read the values of whats currently there into 'hwparams' and then change what we want
	if (snd_pcm_hw_params_any(*pcm_handle, *hwparams) < 0) {
		fprintf(stderr, "Can not get configuration this PCM device. \n");
		return(-1); // Fail
	}

	// Set the access type to Read/Write Interleaved Data (alternating words of sample data for the left and right channel)
	if (snd_pcm_hw_params_set_access(*pcm_handle, *hwparams, SND_PCM_ACCESS_RW_INTERLEAVED) < 0) {
		fprintf(stderr, "Error setting access type\n");
		return(-1);
	}

	// Set sample format to 16 bit little endian
	if (snd_pcm_hw_params_set_format(*pcm_handle, *hwparams, SND_PCM_FORMAT_S16_LE) < 0) {
		fprintf(stderr, "Error setting format\n");
		return(-1);
	}

	// Set sample rate.
	// If the exact rate is not supported by the hardware, use the nearest rate
	exact_rate = SAMPLE_RATE;
	if (snd_pcm_hw_params_set_rate_near(*pcm_handle, *hwparams, &exact_rate, &dir) < 0) {
		fprintf(stderr, "Error setting rate\n");
		return(-1);
	}
	if (dir != 0) {
		fprintf(stderr, "The rate %d Hz is not supported by your hardware. Using %d Hz instead.\n", SAMPLE_RATE, exact_rate);
	}

	// Set number of channels (2 for stereo or 1 for mono)
	if (snd_pcm_hw_params_set_channels(*pcm_handle, *hwparams, NUM_CHANNELS) < 0) {
		fprintf(stderr, "Error setting channels.\n");
		return(-1);
	}

	// Set number of periods per hardware buffer (a.k.a. 'fragments')
	if (snd_pcm_hw_params_set_periods(*pcm_handle, *hwparams, (unsigned int)PERIODS_PER_HW_BUF, 0) < 0) {
		fprintf(stderr, "Error setting periods\n");
		return(-1);
	}

	// Set hardware buffer size in terms of a number of frames
	// A 'frame' is the number of bytes in all channels per sample (e.g. 16 bit has 2 bytes per channel * 2 channels = 4 bytes per frame)
	exact_frames = FRAMES_PER_HW_BUF;
	if (snd_pcm_hw_params_set_buffer_size_near(*pcm_handle, *hwparams, &exact_frames) < 0) {
		fprintf(stderr, "Error setting buffer size. \n");
		return(-1);
	}
	if (exact_frames != (snd_pcm_uframes_t)FRAMES_PER_HW_BUF) {
		fprintf(stderr, "The buffer size of %lu frames is not supported by your hardware. Using buffer size of %lu frames instead.\n", (snd_pcm_uframes_t)FRAMES_PER_HW_BUF, exact_frames);
	}

	// Apply the configuration properties to the PCM device pointed to by pcm_handle
	if (snd_pcm_hw_params(*pcm_handle, *hwparams) < 0) {
		fprintf(stderr, "Error setting HW params.\n");
		return(-1);
	}

	printf("End of stream function\n");
	return(0);  // Success
}

long readbuf(snd_pcm_t* handle, char* buf, long len, size_t* frames, size_t* max)
{
	long r;
	_snd_pcm_format format = SND_PCM_FORMAT_S16_LE;
	int channels = 2;
	int frame_bytes = (snd_pcm_format_width(format) / 8) * channels;

	while (len > 0) {
		r = snd_pcm_readi(handle, buf, len);
		if (r == -EAGAIN)
			continue;
		if (r < 0)
			return r;
		//printf("read = %li\n", r);
		buf += r * frame_bytes;
		len -= r;
		*frames += r;
		if ((long)* max < r)
			* max = r;
	}
	return r;
}

long writebuf(snd_pcm_t* handle, char* buf, long len, size_t* frames)
{
	long r;
	int channels = 2;
	_snd_pcm_format format = SND_PCM_FORMAT_S16_LE;
	int frame_bytes = (snd_pcm_format_width(format) / 8) * channels;
	while (len > 0) {
		r = snd_pcm_writei(handle, buf, len);
		if (r == -EAGAIN)
			continue;
		//printf("write = %li\n", r);
		if (r < 0)
			return r;
		buf += r * frame_bytes;
		len -= r;
		*frames += r;
	}
	return 0;
}
#endif

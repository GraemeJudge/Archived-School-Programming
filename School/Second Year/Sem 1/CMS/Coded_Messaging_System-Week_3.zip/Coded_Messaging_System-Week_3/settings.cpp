#include "windowsSound.h"
#include "queue.h"
#include "menu.h"
#include "windowsAudio.h"
#include "windowsMessaging.h"
#include "settings.h"

static MenuChoice audioOptions[] = {
	{"Change Recording Duration", &ChangeRecordTime},
	{"Change Sample Rate", &ChangeSampleRate},
	{"Back To audio menu", &DisplayAudioMenu},
	{"Back to main menu", &DisplayMenu},
};


static MenuChoice messagingOptions[] = {
	{"Change Ports", &ChangeRecordTime},
	{"Change Message Size", &ChangeSampleRate},
	{"Back To audio menu", &DisplayMessagingMenu},
	{"Back to main menu", &DisplayMenu},
};

void DisplayAudioSettingsMenu() {
	char title[] = "Settings Menu";
	int n = sizeof(audioOptions) / sizeof(MenuChoice);
	DisplayTempMenu(title, audioOptions, n);
}

void DisplayMessagingSettingsMenu() {
	char title[] = "Settings Menu";
	int n = sizeof(messagingOptions) / sizeof(MenuChoice);
	DisplayTempMenu(title, messagingOptions, n);
}

void ChangeRecordTime() {
	NotImplemented();
}

void ChangeSampleRate() {
	NotImplemented();
}

#if defined(_WIN32)
	#define PLATFORM_NAME "windows" // Windows
#elif defined(_WIN64)
	#define PLATFORM_NAME "windows" // Windows
#elif defined(__linux__)
	#define PLATFORM_NAME "linux"
#endif
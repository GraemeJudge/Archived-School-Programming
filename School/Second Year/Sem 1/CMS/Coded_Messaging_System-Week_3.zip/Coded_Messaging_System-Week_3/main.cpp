/* main.cpp - Main file for testing the Coded Messaging System project
*  By: Graeme Judge, Stephane Durette, Ruchi Patil
*/


#include"queue.h"
#include"windowsSound.h"
#include "menu.h"

int main(int argc, char** argv) {
	DisplayMenu();
}


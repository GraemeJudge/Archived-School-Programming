/* Queue.cpp

   This is a cpp file containing all of the spporting functions for the queue

	Authors: Stephane Durette, Graeme Judge, Rushi Patil
	Date: October 9, 2019
	Change Log:
		Oct 9, 2019 - Source file created
*/



#include"queue.h"

static NODE* head;
static NODE* tail;

void InitQueue() {
	head = tail = NULL;					//Sets head and tail to NULL inititally since theres nothing to point o
}

void Push(NODE* node) {
	if (head == NULL) {
		head = tail = node;
	}
	else {
		tail->pNext = node;
	}
	node->pNext = NULL;
	tail = node;


}

NODE* Pop() {
	if (head == NULL) {
		return NULL;
	}
	NODE* temp = head;
	head = head->pNext;
	return temp;
}

int IsQueueEmpty() {
	if (head == NULL) { return 1; }
	return 0;
}

void PrintContents() {
	NODE* p = head;
	while (p != NULL) {
		printf("[%s]", (p->data.message));
		p = p->pNext;
	};
	printf("Message Printing Complete\n");
}

void PrintMessage(link h) {
	if (h->data.message != NULL) {
		printf("\nmessage: %s\n", h->data.message);
	}
}

//Assignemnt 2 additions (traversing)

void traverse(link h, void (*f)(link h)) {
	if (h == NULL) {
		return;
	}
	(*f) (h);
	traverse(h->pNext, f);
}


void traverseR(link h, void (*f)(link h)) {
	if (h == NULL) {
		return;
	}

	traverseR(h->pNext, f);
	(*f)(h);

}

link getHead() {

	return head;
}

link deleteR(link parent, link child, MESSAGE v) {
	if (child == NULL) return NULL;
	if (child->data.senderID == v.senderID) {
		parent->pNext = child->pNext;
		free(child);
		return deleteR(parent, parent->pNext, v);
	}
	else {
		return deleteR(child, child->pNext, v);
	}
}
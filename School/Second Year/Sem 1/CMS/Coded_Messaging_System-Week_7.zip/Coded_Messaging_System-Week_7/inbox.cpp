/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/

#pragma once

#include "inbox.h"
#include "windowsMessaging.h"

boolean displyHeaders = false;

static MenuChoice options[]{										//array of menu options to pick from
	{"Count Messages", &countMessages},
	{"Print All Messages", &printAll},
	{"Print and Delete All Message", &printAndDeleteAll},
	{"Print Message", &printMessage},
	{"Delete Message", &deleteMessage},
	{"Back", &DisplayMessagingMenu},
	{"Exit", &exit}
};



void DisplayInboxMenu() {
	char title[150];
	sprintf_s(title, 150, "Messaging Inbox Menu *******\n******* you have %d message", recieveQ.getCount());			//title for the menu
	int n = sizeof(options) / sizeof(MenuChoice);					//the number of menu choices that are available to pick from
	DisplayTempMenu(title, options, n);								//display the mneu
}

void printAll() {
	for (int i = 1; i <= recieveQ.getCount(); i++)
	{
		recieveQ.printNode(i, displyHeaders);
	}
}


void printAndDeleteAll()
{
	while(!recieveQ.IsQueueEmpty())
	{
		recieveQ.printNode(1, displyHeaders);
		recieveQ.deleteNode(1);
	}
	system("pause");

	DisplayInboxMenu();															//forces the menu to update the count for the number of messages 

}



void countMessages() {
	printf("\nYou have %d new messages\n", recieveQ.getCount());
}


void printMessage() {
	char selection[100];
	int userInput;
	do {
		printf("\Which message do you want to look at?");
		fgets(selection, 100, stdin);
		userInput = atoi(selection);
	} while (userInput < 1 || userInput > recieveQ.getCount());
		printf("number selected: %d\n", userInput);
		recieveQ.printNode(userInput, displyHeaders);
}

void deleteMessage() {
	if (recieveQ.getCount() > 0) {
		char selection[100];
		int userInput;
		do {
			printf("\nWhich message do you want to delete?");
			fgets(selection, 100, stdin);
			userInput = atoi(selection);
		} while (userInput < 1 || userInput > recieveQ.getCount());
		printf("number selected: %d\n", userInput);
		recieveQ.deleteNode(userInput);
	}
	else {
		printf("Sorry there are no messages to delete\n");
		system("pause");
	}
	DisplayInboxMenu();
}
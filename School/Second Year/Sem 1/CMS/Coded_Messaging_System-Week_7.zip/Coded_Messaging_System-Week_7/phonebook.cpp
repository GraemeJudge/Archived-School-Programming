//#include "queue.h"
//#include "treefunc.h"
//
////need bst
////need bst node
////edit bst to compare sender ids on insertion
////edit bst to contain nodes
////need to activate this on reception
//
//
//static bool active;
//static int message_count;
////struct DATA {
////FRAME frame;
////MESSAGE message;
////};
//
//void InitPhonebook() {
//	active = true;
//	BSTInit();
//}
//void SetPhonebookActive(bool _active) {
//	active = _active;
//}
//void PhonebookInsert(DATA d) {
//	if (!active) return;
//	//search for the sender id, if it exists push it onto the queue
//	//if the sender id doesn't exist create a new queue and insert it into the bst
//	long int senderId = d.message.senderID;
//	senderData sd;
//	sd.senderId = d.message.senderID;
//	senderData senderInfo = Search(sd);
//	if (senderInfo.senderId == -1) {				//No match
//		sd.messages = queue();
//		Insert(sd);
//		printf("Inserting");
//	} else {
//		link newNode = (link)malloc(sizeof(NODE));
//		//newNode->data = d;
//		senderInfo.messages.Push(newNode);
//	}
//}
//
//int PhonebookRetrieveMessages(char** messageList, long int senderID) {
//	senderData sd;
//	sd.senderId = senderID;
//	senderData senderInfo = Search(sd);
//	if (senderInfo.senderId == -1) return 0;
//	
//	return senderInfo.messages.getCount();
//}
//
//void PhonebookPrintAllMessages() {
//	BSTPrint(getRoot());
//}
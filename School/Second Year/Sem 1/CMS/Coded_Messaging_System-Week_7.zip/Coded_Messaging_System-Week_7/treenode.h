/*
	treenode.h - Header file that contains the node structure of a BST
	Copyright 2019 Stephane Durette
*/
#pragma once
#define _CRT_SECURE_NO_WARNINGS

#include "queue.h"
const int iLength = 140;

//Define the structure of nodes in a BST

typedef struct BSTNode* Tlink;
typedef struct item Item;
typedef struct BSTNode TNode;
typedef struct senderData senderData;

//Define the Item - content of the BST nodes
//struct item {
//	char buff[iLength];
//	int senderId;
//};

struct senderData {
	long int senderId;
	queue messages;
};

struct BSTNode { //DATA protocol
	senderData msg;			//message queue
	Tlink pLeft;			//left subtree
	Tlink pRight;		//right subtree
};

/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/

#include "audioInbox.h"
#include "windowsAudio.h"
#include "sound.h"
#include "menu.h"

boolean displayAudioHeaders = true;

ADATA holder;

union charToShort {
	short shrt[(RECORD_TIME * SAMPLES_SEC)];
	char cr[(RECORD_TIME * SAMPLES_SEC) * 2];		//2 bytes per sample times number of samples
}charToShort;

static MenuChoice options[]{
	{"Count Messages", &countAudioMessages},
	{"Play Message", &playAudioMessage},
	{"Delete Audio Message", &deleteAudioMessage},
	{"Delete All Audio Messages", &DeleteAllAudio},
	{"Back", &DisplayAudioMenu},
	{"Exit", &exit},
};

void DisplayAudioInboxMenu() {
	char title[150];
	sprintf_s(title, 150, "Audio Inbox Menu *******\n******* you have %d message", audioRecieveQ.getCount());			//title for the menu
	int n = sizeof(options) / sizeof(MenuChoice);					//the number of menu choices that are available to pick from
	DisplayTempMenu(title, options, n);								//display the mneu
}

void DeleteAllAudio() {
	while (!audioRecieveQ.IsQueueEmpty())
	{
		audioRecieveQ.deleteNode(1);
	}
	printf("\nAll messages deleted\n");
	DisplayAudioInboxMenu();
}
   
void deleteAudioMessage() {
	if (audioRecieveQ.getCount() > 0) {
		char selection[100];
		int userInput;
		do {
			printf("\Which message do you want to delete?");
			fgets(selection, 100, stdin);
			userInput = atoi(selection);
		} while (userInput < 1 || userInput > audioRecieveQ.getCount());
		printf("number selected: %d\n", userInput);
		audioRecieveQ.deleteNode(userInput);
	}
	else {
		printf("Im sorry theres no messages to delete\n");
	}
	DisplayAudioInboxMenu();
}

void playAudioMessage() {
	if (audioRecieveQ.getCount() > 0) {
		char selection[100];
		int userInput;
		do {
			printf("Which message do you want to listen to?");
			fgets(selection, 100, stdin);
			userInput = atoi(selection);
		} while (userInput < 1 || userInput > audioRecieveQ.getCount());
		printf("number selected: %d\n", userInput);
		holder = audioRecieveQ.getNode(userInput)->data;
		if (displayAudioHeaders) {
			printHeaders(holder.frame);
		}

		memcpy_s(charToShort.cr, sizeof(charToShort.cr), holder.audio.message, sizeof(charToShort.cr));

		InitializePlayback();

		PlayBuffer(charToShort.shrt, sizeof(charToShort.shrt) / SAMPLE_SIZE);

		ClosePlayback();
	}
	else {
		printf("Im sorry theres no messages to play\n");
	}
}

void countAudioMessages() {
	printf("You have %d audio messages\n",audioRecieveQ.getCount());

}

void printHeaders(FRAME frame) {
	printf("\nSignature:          %lx\nReciever Address:   %lx\nVersion:            %c\nData Length:        %lx\nData Type:          %c\nPattern:            %c\n",
		frame.signature,
		frame.recieverAddress,
		frame.version,
		frame.dataLength,
		frame.dataType,
		frame.pattern);
}
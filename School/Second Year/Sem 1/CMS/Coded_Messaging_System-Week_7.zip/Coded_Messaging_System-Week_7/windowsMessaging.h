/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/

#include "message.h"
#include "Queue.h"
#include <Windows.h>
#include <stdio.h>
#include <Thread>

// Prototype the functions to be used
extern queue sendQ;									//queue to hold the items waiting to be sent 
extern queue recieveQ;								//queue to hold the items that have been recieved

extern boolean running;

void InitWindowsMessaging();


static long signature = 0xDEADBEEF;
static byte recieverAddress = 0x41;
static byte version = 0x41;
static long dataLength = 0XFEEBDAED;
static byte pattern = 0x42;


//queue and thread based sending and recieving stuff
/*
	void setUpRecieving;

	sets up the thread for the sending and recieving multi-threading to 
	run in the background determining if the threads will be using 1 
	shared port or if they are to use 2 sperate ports

	Input: None
	Output: None
*/
void setUpRecieving();
/*
	void ThreadedRun;

	the function that the thread runs that handles the 
	recieving and queueing of messages

	Input: None
	Output: None
*/
void ThreadedRun();
/*
	void sendRun;

	Threaded function to hande the sending of messages so
	that it can be split onto 2 different ports without downtime

	Input: None
	Output: None
*/
void sendRun();
/*
	void funcName;

	Threaded function to hande the recieving of messages so
	that it can be split onto 2 different ports without downtime

	Input: None
	Output: None
*/
void recieveRun();

//menu
void DisplayMessagingMenu();


//***************************************//
//***************************************//
//***************************************//
//************ SEND MESSAGE *************//
/*
	void toSend;

	Attaches the header frame to the message waiting to be 
	sent then sends the first one in the queue

	Input: None
	Output: None
*/
void tosend();
/*
	void sendMessage;

	Takes the users input and puts it into the sending queue to be sent when available

	Input: None
	Output: None
*/
void sendMessage();
void sendRandomFortune();
void initSendPort();
void createSendPortFile();


//***************************************//
//***************************************//
//***************************************//
//************ RECIEVE MESSAGE **********//
/*
	void toRecieve;

	Handles the recieving and queueing of messages
	and opening, closing and purging of the port

	Input: None
	Output: None
*/
void toRecieve();
/*
	void recieveMessage;

	Prints out and clears all of the 
	messages in the queue

	Input: None
	Output: None
*/
void recieveMessage();
/*
	void countMessages;

	Counts the number of messages in the queue and 
	prints the number out

	Input: None
	Output: None
*/
void countMessages();
void initRecievePort();
void createRecievePortFile();


//com port things
static int SetComParms(HANDLE hCom);
long inputFromPort(LPVOID buf, DWORD szBuf);
void outputToPort(LPCVOID buf, DWORD szBuf);
void purgePort(HANDLE hCom);

void purgeSendPort();
void purgeRecievePort();

void closeSendHandle();
void closeRecieveHandle();
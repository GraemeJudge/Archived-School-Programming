

#include"queue.h"
#include"sound.h"
#include"WindowsAudio.h"											//may not need as the playback is in audio.h


union audioConverter {													//union to be used to convert the data to a character buffer to be sent
	ADATA data;														//the DATA struct to be used in the union
	char buffer[sizeof(ADATA)];										//the character buffer to be used for the union
} audioConverter;


audioQueue::audioQueue() {
	InitQueue();
}

void audioQueue::InitQueue() {
	head = tail = NULL;					//Sets head and tail to NULL inititally since theres nothing to point at
}

void audioQueue::Push(ANODE* node) {
	if (head == NULL) {
		head = tail = node;
	}
	else {
		tail->pNext = node;
	}	
	node->pNext = NULL;
	tail = node;
}

ANODE* audioQueue::Pop() {
	if (head == NULL) {
		return NULL;
	}
	ANODE* temp = head;
	head = head->pNext;
	return temp;
}

int audioQueue::IsQueueEmpty() {
	if (head == NULL) { return 1; }
	return 0;
}

void audioQueue::PrintContents() {
	ANODE* p = head;
	while (p != NULL) {
		printf("[%s]", (p->data.audio.message));
		p = p->pNext;
	};
	printf("Message Printing Complete\n");
}

void audioQueue::PrintMessage(aLink h) {

	if (h->data.audio.message != NULL) {
		printf("\nmessage: %s\n", h->data.audio.message);
	}
}

void audioQueue::traverse(aLink h, void (*f)(aLink h)) {
	if (h == NULL) {
		return;
	}
	(*f) (h);
	traverse(h->pNext, f);
}

void audioQueue::traverseR(aLink h, void (*f)(aLink h)) {
	if (h == NULL) {
		return;
	}

	traverseR(h->pNext, f);
	(*f)(h);

}

aLink audioQueue::getHead() {

	return head;
}

aLink audioQueue::deleteR(aLink parent, aLink child, AUDIO v) {
	if (child == NULL) return NULL;
	if (child->data.audio.senderID == v.senderID) {
		parent->pNext = child->pNext;
		free(child);
		return deleteR(parent, parent->pNext, v);
	}
	else {
		return deleteR(child, child->pNext, v);
	}
}


int audioQueue::getCount()
{
	int count = 0; // Initialize count  
	aLink current = getHead(); // Initialize current  
	while (current != NULL)
	{
		count++;
		current = current->pNext;
	}
	return count;
}

void audioQueue::printNode(int number, boolean withFrame) {
	if (number <= getCount()) {
		aLink holder = getHead();
		for (int i = 0; i < number - 1; i++)
		{
			holder = holder->pNext;
		}

		audioConverter.data = holder->data;
		if (withFrame) {
			printf("\nFrame for message number %d:", number);
			printf("\nSignature:          %lx\nReciever Address:   %lx\nVersion:            %c\nData Length:        %lx\nData Type:          %c\nPattern:            %c",
				audioConverter.data.frame.signature,
				audioConverter.data.frame.recieverAddress,
				audioConverter.data.frame.version,
				audioConverter.data.frame.dataLength,
				audioConverter.data.frame.dataType,
				audioConverter.data.frame.pattern);
		}
		printf("\nMessage:            %s\n\n\n", audioConverter.data.audio.message);
	}
}

void audioQueue::deleteNode(int number) {
	if (number <= getCount() && number > 0) {
		aLink holder = getHead();

		if (number == 1) {
			head = holder->pNext;
			free(holder);
			return;
		}
		else {
			for (int i = 1; i < number - 1; i++)
			{
				holder = holder->pNext;
			}
			if (holder->pNext->pNext == NULL) {
				free(holder->pNext);
				holder->pNext = NULL;
				tail = holder->pNext;
				return;
			}
			else {
				aLink temp = holder->pNext;
				holder->pNext = temp->pNext;
				free(temp);
				return;
			}

		}
	}
}

aLink audioQueue:: getNode(int number) {
	if (number <= getCount()) {
		aLink holder = getHead();
		for (int i = 0; i < number - 1; i++)
		{
			holder = holder->pNext;
		}
		return(holder);
	}
}
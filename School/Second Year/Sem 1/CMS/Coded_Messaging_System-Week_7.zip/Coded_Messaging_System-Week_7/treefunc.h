/*
	treefunc.h - Header file that contains the function prototypes for a BST
	Copyright 2019 Stephane Durette
*/
#define _CRT_SECURE_NO_WARNINGS
#include "treenode.h"

//function prototypes
Tlink NEW(senderData item, Tlink left, Tlink right);		//creates a new BST node
void BSTInit(void);								//initialize the BST
senderData BSTsearch(Tlink h, char* szSearchKey);		//private search function called by "Search()"
senderData Search(senderData szKey);						//public search function
Tlink BSTInsert(Tlink h, senderData item);				//private insert function called by "Insert()"
void Insert(senderData item);						//public search function
void BSTPrint(Tlink h);							//Private print function 
int height(Tlink h);								//returns the height of the tree
int count(Tlink h);								//returns the number of nodes in the tree
Tlink getRoot(void);								//returns a pointer to the root of the BST


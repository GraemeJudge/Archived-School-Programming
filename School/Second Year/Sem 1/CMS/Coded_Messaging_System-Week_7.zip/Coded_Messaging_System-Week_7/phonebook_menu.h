#include <ctime>
#define _CRT_SECURE_NO_WARNINGS
#define Max_ID 0xFE

struct senderInfo {
	int msgCount;
	time_t lastMessageTime;
};


void DisplayContents();
void InitPhonebook();
void addPhonebookEntry(long int senderID);
#include "sound.h"
#include "queue.h"
#include "menu.h"
#include "windowsAudio.h"
#include "windowsMessaging.h"
#include "settings.h"
#include <windows.h>

static MenuChoice audioOptions[] = {
	{"Change Recording Duration", &ChangeRecordTime},
	{"Change Sample Rate", &ChangeSampleRate},
	{"Back", &DisplayAudioMenu},
	{"Back to main menu", &DisplayMenu},
};

static MenuChoice messagingOptions[] = {
	{"Set Tx", &Set_Tx},
	{"Set Rx", &Set_Rx},
	{"Set single port", &SetSinglePort},
	{"Change Message Size", &ChangeSampleRate},
	{"Back", &DisplayMessagingMenu},
	{"Back to main menu", &DisplayMenu},
};

void DisplayAudioSettingsMenu() {
	char title[] = "Settings Menu";
	int n = sizeof(audioOptions) / sizeof(MenuChoice);
	DisplayTempMenu(title, audioOptions, n);
}

void Set_Tx() {
	char buf[1024];
	int userInput;
	do {
		printf("\nEnter a valid COM port number: ");
		fgets(buf, 1024, stdin);
		userInput = atoi(buf);
	} while (userInput < 0 || userInput > 100);
	WritePrivateProfileString("Messaging","TxId",buf,"./settings.txt");
	printf("\nTx is now: COM%s", buf);
}

void Set_Rx() {
	char buf[1024];
	int userInput;
	do {
		printf("\nEnter a valid COM port number: ");
		fgets(buf, 1024, stdin);
		userInput = atoi(buf);
	} while (userInput < 0 || userInput > 100);
	WritePrivateProfileString("Messaging", "RxId", buf, "./settings.txt");
	printf("\nRx is now: COM%s", buf);
}

void SetSinglePort() {
	running = false;
	Sleep(1000);
	setUpRecieving();
}

void DisplayMessagingSettingsMenu() {
	char title[] = "Settings Menu";
	int n = sizeof(messagingOptions) / sizeof(MenuChoice);
	DisplayTempMenu(title, messagingOptions, n);
}

void ChangeRecordTime() {
	NotImplemented();
}

void ChangeSampleRate() {
	NotImplemented();
}
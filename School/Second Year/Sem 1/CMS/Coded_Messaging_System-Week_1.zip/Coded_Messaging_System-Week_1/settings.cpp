#include "sound.h"
#include "queue.h"
#include "menu.h"
#include "audio.h"
#include "settings.h"

static MenuChoice options[] = {
	{"Change Bitrate", &ChangeBitrate},
	{"Change Recording Duration", &ChangeRecordTime},
	{"Change Sample Rate", &ChangeSampleRate},
	{"Back To audio menu", &DisplayAudioMenu},
	{"Back to main menu", &DisplayMenu},
};

void DisplaySettingsMenu() {
	char title[] = "Settings Menu";
	int n = sizeof(options) / sizeof(MenuChoice);
	DisplayTempMenu(title, options, n);
}

void ChangeBitrate() {
	NotImplemented();
}

void ChangeRecordTime() {
	NotImplemented();
}

void ChangeSampleRate() {
	NotImplemented();
}
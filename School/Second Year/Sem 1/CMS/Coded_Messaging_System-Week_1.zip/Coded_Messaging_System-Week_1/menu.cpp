/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/



#include <stdio.h>
#include <stdlib.h>
#include <String.h>
#include "menu.h"
#include "audio.h"


static MenuChoice options[] = {
	{"Audio", &DisplayAudioMenu},
	{"Placeholder", &NotImplemented},
	{"Exit", &exit},
};

void DisplayMenu() { //eventually will call the the gui menu 
	char title[] = "Main Menu";
	int n = sizeof(options) / sizeof(MenuChoice);
	DisplayTempMenu(title, options, n);
}

void NotImplemented() {
	printf("\nSorry this function is not implemented yet!");
}


//todo cleaning this
void DisplayTempMenu(char title[], MenuChoice *options, int size) {
	system("@cls||clear");
	int nOptions = size;
	printf("******* %s *******\n", title);
	for (int i = 1; i <= nOptions; i++) {
		char* buf;
		printf("\n%d.\t%s", i, options[i - 1].name);
	}
	printf("\n");
	char buf[1024];
	int userInput;
	do {
		printf("\nPlease pick an option between 1 and %d: ", nOptions);
		fgets(buf, 1024, stdin);
		userInput = atoi(buf);
	} while (userInput < 1 || userInput > nOptions);

	options[userInput - 1].action();
}



void exit() {
	printf("\nExiting thanks for using me!\n\n");
}
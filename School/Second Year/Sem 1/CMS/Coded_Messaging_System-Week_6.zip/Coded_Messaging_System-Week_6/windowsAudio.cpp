/* windowsAudio.cpp -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/

#include "sound.h"
#include "audioInbox.h"
#include "menu.h"
#include "windowsAudio.h"
#include "windowsMessaging.h"
#include "settings.h"
#include "huffman.h"

audioQueue audioRecieveQ = audioQueue();
audioQueue audioSendQ = audioQueue();


union shortToChar {
	short shrt[(RECORD_TIME * SAMPLES_SEC)];
	char cr[(RECORD_TIME * SAMPLES_SEC) * 2];		//2 bytes per sample times number of samples
}shortToChar;

union audioToChar {
	ADATA data;
	char buffer[sizeof(ADATA)];
}audioToChar;


static MenuChoice options[] = {
	{"Record and Send", &recordAndSend},
	{"Inbox", &DisplayAudioInboxMenu},
	{"Record and Playback Demo", &recordAndPlay},
	{"Play Audio From File", &playFromFile},
	{"Change Settings", &DisplayAudioSettingsMenu},
	{"Back", &DisplayMenu},
	{"Exit", &exit}
};


void DisplayAudioMenu() {
	char title[] = "Audio Menu";
	int n = sizeof(options) / sizeof(MenuChoice);
	DisplayTempMenu(title, options, n);
}

void ChangeSettings() {
	//settings stuff 
		//save and load file location and file name
		//length of recording ();
	printf("changing the settings");
	NotImplemented();
}

void recordAndPlay() {
	char save;
	char c;
	extern short iBigBuf[];					//buffer to store the recorded data into
	extern long lBigBufSize;				//number of samples used by the audio recording


	InitializePlayback();
	InitializeRecording();

	//record sound
	RecordBuffer(iBigBuf, lBigBufSize);
	CloseRecording();

	//playback from buffer
	printf("\nStarting audio playback from buffer\n");
	PlayBuffer(iBigBuf, lBigBufSize);
	ClosePlayback();

	printf("\nWould you like to save the audio recording to a file? (y/n):");
	scanf_s("%c", &save, 1);
	while ((c = getchar()) != '\n' && c != EOF) {}										//clears input buffers before moving to the next step
	if ((save == 'y') || (save == 'Y')) {
		saveToFile(shortToChar.shrt, lBigBufSize);
	}
	else {
		printf("\nAudio not being saved, returning to menu\n");
	}
}

void recordAndSend() {
	boolean exFlag = false;
	char selection[100];
	extern short iBigBuf[];																//buffer to store the recorded data into
	extern long lBigBufSize;															//number of samples used by the audio recording

	InitializeRecording();

	//record sound
	RecordBuffer(iBigBuf, lBigBufSize);
	CloseRecording();

	do {
		printf("\nWould you like to preview the audio before sending?(y/n)");
		fgets(selection, 100, stdin);
		if (selection[0] == 'y' || selection[0] == 'Y') {									//play audio then send
			InitializePlayback();
			//playback from buffer
			printf("\nStarting audio playback from buffer\n");
			PlayBuffer(iBigBuf, lBigBufSize);
			ClosePlayback();
			exFlag = true;
		}
		if (selection[0] == 'n' || selection[0] == 'N') {									//dont playback audio
			exFlag = true;
		}
	} while (!exFlag);

	exFlag = false;
	selection[100];
	do {
		printf("\nWould you like to send the audio?(y/n)");
		fgets(selection, 100, stdin);
		if (selection[0] == 'y' || selection[0] == 'Y') {									//play audio then send
			enqueueForSend(iBigBuf);
			exFlag = true;
		}
		if (selection[0] == 'n' || selection[0] == 'N') {									//dont playback audio
			exFlag = true;
		}
	} while (!exFlag);
}


void enqueueForSend(short* buffer) {
	ANODE* newNode = (aLink)malloc(sizeof(ANODE));

	FRAME newFrame;													//frame setup
	newFrame.pattern = pattern;
	newFrame.recieverAddress = recieverAddress;
	newFrame.signature = signature;
	newFrame.version = version;
	newFrame.dataType = 0x41;
	newFrame.dataLength = sizeof(shortToChar);

	memcpy_s(shortToChar.shrt, sizeof(shortToChar.shrt), buffer, sizeof(shortToChar.shrt));		//passes into the union so we can

	//set up for the message tobe sent
	AUDIO newMessage = { "",0,0,0,0,{0} };
	memcpy_s(newMessage.message, sizeof(shortToChar.cr), shortToChar.cr, sizeof(shortToChar.cr));

	ADATA data = { newFrame, newMessage };
	newNode->data = data;
	audioSendQ.Push(newNode);
}

int saveToFile(short *iBigBuf, long lBigBufSize) {
	char c;
	char fileName[1024];
	GetPrivateProfileString("Audio", "recordingFileName", NULL, fileName, 1024, ".\\settings.txt");
	FILE* fp;					//file pointer
			fopen_s(&fp, fileName, "wb"); //need the file pointer still
			if (!fp) {
				printf("unable to open file");
				return 1;
			}
			printf("\nWriting to sound file");
			fwrite(iBigBuf, sizeof(short), lBigBufSize, fp);
			fclose(fp);
			printf("\nSound file written! Retruning to menu\n");

	return 0;
}

void playFromFile() {
	char replay;
	char c;

	int audioLength;

	extern long lBigBufSize;				//number of samples used by the audio recording
	short* loadBuffer = (short*)malloc(lBigBufSize * sizeof(short));		// buffer used for reading recorded sound from file

	FILE* fp;
	
	printf("\nWould you like to read the audio file?(y/n) ");
	scanf_s("%c", &replay, 1);

	// replay audio recording from file -- read and store in buffer, then use playback() to play it
	while ((c = getchar()) != '\n' && c != EOF) {}								// Flush other input
	if ((replay == 'y') || (replay == 'Y')) {
		/* Open input file */
		char fileName[1024];
		GetPrivateProfileString("Audio", "recordingFileName", NULL, fileName, 1024, ".\\settings.txt");
		fopen_s(&fp, fileName, "rb");
		if (!fp) {
			printf("unable to open %s\n", fileName);
		}

		audioLength = getAudioLength(fp);

		printf("audio length: %d\n",audioLength);



		printf("Reading from sound file ...\n");
		fread(loadBuffer, sizeof(short), audioLength * SAMPLES_SEC, fp);				// Record to new buffer iBigBufNew
		fclose(fp);
		printf("\nPlaying recorded audio from saved file ...\n");
		InitializePlayback();
		PlayBuffer(loadBuffer, audioLength * SAMPLES_SEC);
		ClosePlayback();

		printf("\nFinished playing audio from saved file! Retruning to menu\n");
	}
	else {
		printf("\nOkay no audio will be played! Retruning to the menu\n");
	}
}


int getAudioLength(FILE* fp) {
	int size;
	fseek(fp, 0, SEEK_END); // seek to end of file
	size = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	return(size/(SAMPLES_SEC * sizeof(short)));
}




void audioSend() {
	initSendPort();
	ANODE* newNode = audioSendQ.Pop();
	//audioToChar.data = newNode->data;


	int can_compress = GetPrivateProfileInt("Messaging", "canCompress", 0, ".\\settings.txt");
	if (can_compress == 1) {
		printf("\nCompressing audio\n");
		unsigned char* compressedAudio = (unsigned char*)malloc((sizeof(shortToChar.cr)) + 384);
		int compressedSize = Huffman_Compress((unsigned char*)newNode->data.audio.message, compressedAudio, sizeof(shortToChar.cr));
		printf("\nCompressed size: %d \n", compressedSize);
		newNode->data.frame.compressed_length = compressedSize;
		newNode->data.frame.dataLength = sizeof(shortToChar.cr);
		memcpy_s(newNode->data.audio.message, sizeof(newNode->data.audio.message), compressedAudio, compressedSize);
	}

	audioToChar.data = newNode->data;

	outputToPort(audioToChar.buffer, sizeof(ADATA));


	Sleep(1000);													//give it a second to make sure it sends
	
	purgeSendPort();
	closeSendHandle();
}
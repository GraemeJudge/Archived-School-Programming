/*
	treefunc.cpp - Implementation of BST
	Copyright 2019 Stephane Durette
*/

#include "treefunc.h"
#include "treenode.h"
#include <stdio.h>;
#include <stdlib.h>;
#include <string.h>;
//#define NULL 0

//Private variables
static Tlink root;				//root of the BST
static senderData NullItem = {-1,queue()};	//indicate that a searched message has not been found

//Function implementations


Tlink NEW(senderData item, Tlink left, Tlink right) {
	Tlink pNew = (Tlink)malloc(sizeof(TNode));
	pNew->msg = item;
	pNew->pLeft = left;
	pNew->pRight = right;
	return pNew;
}

void BSTInit(void) {
	root = NEW(NullItem, NULL, NULL);
}

senderData BSTsearch(Tlink h, senderData item) {
	if (h == NULL) return(NullItem);		//terminal condition - reached leaf node and did not find szSearchKey
	//int rc = strcmp(szKey.senderId, h->msg.senderData);
	int rc;
	if ((item.senderId) > (h->msg.senderId)) {
		rc = 1;
	}
	else if ((item.senderId) < (h->msg.senderId)) {
		rc = -1;
	} else {
		rc = 0;
	}

	if (rc == 0)	return h->msg;
	if (rc > 0)		return (BSTsearch(h->pRight, item));
	else			return (BSTsearch(h->pLeft, item));
}

senderData Search(senderData szKey) {
	return(BSTsearch(root, szKey));
}

Tlink BSTInsert(Tlink h, senderData item) {
	if (h == NULL) return(NEW(item, NULL, NULL));		//terminal condition - reached leaf node and did not find szSearchKey
	//int rc = strcmp(item.buff, h->msg.buff);
	//printf("Key 1: %d,       Key 2: %d\n", item.hashKey, h->msg.hashKey);
	if ((item.senderId) > (h->msg.senderId)) {
		h->pRight = BSTInsert(h->pRight, item);
	} else {
		h->pLeft = BSTInsert(h->pLeft, item);
	}

	return h;
}


void Insert(senderData item) {
	BSTInsert(root, item);
}

void BSTPrint(Tlink h) {
	if (h == NULL) return;
	BSTPrint(h->pLeft);
	printf("\nSender: %d\n", h->msg.senderId);
	h->msg.messages.PrintContents();
	BSTPrint(h->pRight);
}

int height(Tlink h) {
	if (h == NULL) return -1;
	
	int iLeftH = height(h->pLeft);
	int iRightH = height(h->pRight);
	if (iLeftH > iRightH) return iLeftH + 1;
	else return iRightH + 1;
}

int count(Tlink h) {
	if (h == NULL) return 0;

	return(count(h->pLeft) + count(h->pRight) + 1);
}

Tlink getRoot(void) {
	return root;
}

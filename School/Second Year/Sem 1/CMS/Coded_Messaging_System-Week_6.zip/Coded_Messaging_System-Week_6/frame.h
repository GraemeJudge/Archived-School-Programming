/* frame.h - function prototypes for all of functions used by the frame.cpp and the structure definitions
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			Novemeber 21, 2019: Source file created
*/
#include <windows.h>
#include <stdint.h>

//structure to hold the frame information to be sent along with the data
struct FRAME {
	long signature;
	byte recieverAddress;
	byte version;
	byte dataType;						//'A' for audio (0x41) 'M' for messages (0x4D) and 0xff for voteon diagnostics
	long dataLength;
	byte pattern;
	int compressed_length;
	uint32_t CRC_code;
};

//add int compressed_length









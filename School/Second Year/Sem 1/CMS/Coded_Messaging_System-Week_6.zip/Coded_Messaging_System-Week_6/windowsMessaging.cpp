/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/

#include "windowsMessaging.h"
#include "windowsAudio.h"
#include "inbox.h"
#include "settings.h"
#include <cstdio>
#include <stdlib.h>
#include <string.h>
#include "phonebook.h"
#include "phonebook_menu.h"
#include "rle.h"
#include "MaxHeap.h"
#include "crc.h"
#include "VoteOn.h"

#define EX_FATAL 1
#define BUFSIZE 140

#define SENDCOMPORT	"\\\\.\\COM15"
#define RECIEVECOMPORT "\\\\.\\COM15"

HANDLE RhCom;														// Pointer to a COM port
HANDLE ShCom;														// Pointer to a COM port
int nComRate = 3 * 9600;												// Baud (Bit) rate in bits/second 
//int nComRate = 115200;											// Baud (Bit) rate in bits/second 
//int nComRate = 9600;												// Baud (Bit) rate in bits/second 
int nComBits = 8;													// Number of bits per frame
COMMTIMEOUTS timeout;												// A commtimout struct variable

static short senderId;

boolean running = false;											//variable to stop the thread (likely will be changing this one)
boolean singlePort = false;											//to alternate back and forth from using a single port to 2 seperate ports for running 

FRAME voteOn[3] = {NULL, NULL, NULL};								//to save the vote on frames into to check later
int voteOnCounter = 0;												//

union messageConvert {												//union to be used to convert the data to a character buffer to be sent
	DATA data;														//the DATA struct to be used in the union
	char buffer[sizeof(DATA)];										//the character buffer to be used for the union
} messaegConverter;													//name of the union

union audioConvert{													//union to be used to convert the data to a character buffer to be sent
	ADATA data;														//the DATA struct to be used in the union
	char buffer[sizeof(ADATA)];										//the character buffer to be used for the union
} audioConverter;													//name of the union
									

//queues for sending and recieving data
queue sendQ = queue();												//queue to holding messages waiting to send
queue recieveQ = queue();											//queue to hold the messages that have been recieved
MaxHeap Heap = MaxHeap(512);

static MenuChoice options[]{										//array of menu options to pick from
	{"Send Message", &sendMessage},
	{"Send Random Fortune", &sendRandomFortune},
	{"Inbox", &DisplayInboxMenu},
	{"Show sender info", &DisplayContents},
	{"Change Settings", &DisplayMessagingSettingsMenu},
	{"Print Priority Contents", &PrintMaxHeapContents},
	{"Error Correction for Header", &ErrorCorrect},
	{"Back to Main Menu", &DisplayMenu},
	{"Exit", &exit}					
};

void PrintMaxHeapContents() {
	Heap.printContents();
}

void InitWindowsMessaging() {
	//loadintprofilething
	senderId = GetPrivateProfileInt("Messaging", "SenderID", 0, ".\\settings.txt");
	setUpRecieving();
	InitPhonebook();
}

void set_sender_id() {
	senderId = GetPrivateProfileInt("Messaging", "SenderID", 0, ".\\settings.txt");
}

void DisplayMessagingMenu() {
	char title[] = "Messaging Menu";								//title for the menu
	int n = sizeof(options) / sizeof(MenuChoice);					//the number of menu choices that are available to pick from
	DisplayTempMenu(title, options, n);								//display the mneu
}


//***************************************//
//***************************************//
//***************************************//
//************** THREADING **************//
void setUpRecieving() {
	boolean todo = true;
	char buf[365];
	do {
		printf("\nWould you like to use only one port? (y/n)");		//asks the user if they want to use a single port or 2
		fgets(buf, 365, stdin);
		if (buf[0] == 'y' || buf[0] == 'Y') {						//if input was yes, set the varible for the single port to true
			singlePort = true;
			todo = false;											//tells the loop to exit
		}
		else if(buf[0] == 'n' || buf[0] == 'N'){					//if input was no, sets the varible for the single port to false
			singlePort = false;	
			todo = false;											//tells the loop to exit		
		}
	} while (todo);									

	running = true;													//sets the threads control variable to being true so the threads will be running 

	if (singlePort) {
		std::thread BOTH(ThreadedRun);								//thread for function ThreadedRun to handle sending and recieving at the same time for using the same port
		BOTH.detach();												//makes it so that the prgram wont wait for the thread to finish before moving on
		//RECIEVE.join();											//makes the program wait for the thread to finish (means just the thread will output so we can see it running)
	}
	else {
		std::thread SEND(sendRun);									//thread for function sendRun to handle sending individually so you can use 2 different ports at the same time
		std::thread RECIEVE(recieveRun);							//thread for function recieveRun to handle recieving individually so you can use 2 different ports at the same time
		SEND.detach();												//detaches the sending thread so the program doesnt wait for it to finish
		RECIEVE.detach();											//detaches the recieving thread so the program doesnt wait for it to finish
	}
}


void recieveRun() {
	while (running) {
		toRecieve();												//handles the reciving and queuing of messages
	}
	printf("Thread Stopped");
}


void sendRun() {
	while (running) {
		if (!sendQ.IsQueueEmpty()) {								//check if theres a message to send
			tosend();												//send the first message that is waiting to be sent
		}															//more messages will be sent as it goes since its in a while loop
		if (!audioSendQ.IsQueueEmpty()) {
			audioSend();
		}
	}
	printf("Thread Stopped");
}


void ThreadedRun() {
	while (running) {												//will continue to run until that boolen os set to false where the execution will end

		toRecieve();												//handles the recieving and queueing of messages and blocking of messages with the wrong reciever address

		if (!sendQ.IsQueueEmpty()) {								//check if theres a message to send
				tosend();											//send the first message that is waiting to be sent
		}	
	}	
	printf("Thread Stopped");
}

//***************************************//
//***************************************//
//***************************************//
//************ SEND MESSAGE *************//
void tosend() {	
	initSendPort();													//initalize the send port to send from
	DATA data = sendQ.Pop()->data;
	char* mes = data.message.message;					//get the first messsage waiting to be sent

	if (data.frame.dataType == 0xff) {
		//skip the initalization of frame and message shit
	}
	else {
		FRAME newFrame;													//frame setup
		newFrame.dataLength = dataLength;
		newFrame.pattern = pattern;
		newFrame.recieverAddress = (unsigned char)GetPrivateProfileInt("Messaging", "ReceiverAddress", 0, ".\\settings.txt");
		newFrame.signature = signature;
		newFrame.version = version;
		newFrame.dataType = 0x4D;

		printf("Receiver address %d", newFrame.recieverAddress);																//set up for the message tobe sent
		MESSAGE newMessage = { "",0,0,0,0,{0} };
		newMessage.priority = (unsigned char)GetPrivateProfileInt("Messaging", "Priority", 0, ".\\settings.txt");
		newMessage.senderID = senderId;
		memcpy_s(newMessage.message, BUFSIZE, mes, strlen(mes));		//good
		//set senderid and priority here

		//CRC HERE
		if (GetPrivateProfileInt("Messaging", "errorDetect", 0, ".\\settings.txt")) {
			newFrame.CRC_code = crc32c(0, (unsigned char*)newMessage.message, sizeof(newMessage.message));
			printf("\nThe CRC code of the sent message is: %d", newFrame.CRC_code);
		}

		//newFrame.CRC_code = getCRC(newMessage.message, sizeof(newMessage));
		//printf("The CRC code is: %d", newFrame.CRC_code);

		//CRC HERE


		//COMPRESS HERE
		int can_compress = GetPrivateProfileInt("Messaging", "canCompress", 0, ".\\settings.txt");
		if (can_compress == 1) {
			printf("\nORIGINAL MESSAGE: %s", newMessage.message);
			char compressedMessage[BUFSIZE + 2];
			newFrame.compressed_length = RLE_Compress((unsigned char*)newMessage.message, (unsigned char*)compressedMessage, BUFSIZE);
			memcpy_s(newMessage.message, BUFSIZE + 2, compressedMessage, newFrame.compressed_length);
			printf("COMPRESSED MESSAGE: %s", newMessage.message);
		}
		//END OF COMPRESSION

		data = { newFrame, newMessage };								//puts the message and the header together into the data struct
	}

	messaegConverter.data = data;											//puts the data struct into the union to convert to a character buffer

	outputToPort(messaegConverter.buffer, sizeof(DATA));					//sends it to the output port

	Sleep(1000);														//give it a second to make sure it sends

	purgeSendPort();												//purge the port
	closeSendHandle();												//close the port
}

void sendMessage() {
	MESSAGE newMessage = { "",0,0,0,0,{0} };						//initalize a new message from the user
	newMessage.senderID = 1;										//Change this so it reads from settings.txt
	int userInput;													
	printf("\nEnter a message\n");
	fgets(newMessage.message, 140, stdin);							//gets the users message and stores it in the new messages nessage field
	
	NODE* newNode = (link)malloc(sizeof(NODE));						//create a new node to put into the sending queue

	if (newNode != NULL) {
		newNode->data.message = newMessage;							//put the message into the node
		sendQ.Push(newNode);										//push the node onto the queue
	}

	printf("\nMessage attempting to send: \n%s\n\n", newMessage.message);

	system("pause");
	DisplayMessagingMenu();
}

void sendRandomFortune() {
	MESSAGE newMessage = { "",0,0,0,0,{0} };						//initalize a new message to store the fortune in to be sent
	newMessage.senderID = 1;
	int set = 0;													//holder for how many fortunes want to be sent
	char buf[1024];													//buffer to hold the 
	while (set < 1) {
		printf("\nPlease pick a number of fortunes to send: ");		
		fgets(buf, 1024, stdin);
		set = atoi(buf);
	}

	for (int i = 0; i < set; i++)									//repeat for the number of fortunes requested
	{
		GetMessageFromFile(newMessage.message, 140);				//get the first 140 characters of a random message from the fortune cookies files
		NODE* newNode = (link)malloc(sizeof(NODE));					//allocate the space for a new node in the sending queue
		if (newNode != NULL) {						
			newNode->data.message = newMessage;						//set the new nodes data
			sendQ.Push(newNode);									//put the new node into the queue
		}
		printf("\nMessage attempting to send: \n%s\n\n", newMessage.message);		//prints the message as a confirmation
	}
	system("pause");
	DisplayMessagingMenu();
}

// Initializes the port and sets the communication parameters
void initSendPort() {
	createSendPortFile();										// Initializes hCom to point to PORT4 (port 4 is used by USB-Serial adapter on my laptop)
	purgeSendPort();											// Purges the COM port
	SetComParms(ShCom);											// Uses the DCB structure to set up the COM port
	purgeSendPort();
}

// Set the hCom HANDLE to point to a COM port, initialize for reading and writing, open the port and set securities
void createSendPortFile() {
	// Call the CreateFile() function 
	//string parsing
	int comNumber = GetPrivateProfileInt("Messaging", "TxId", -1, ".\\settings.txt");
	//printf("%d", comNumber);
	char portString[128];
	if (comNumber > 9) {
		sprintf_s(portString, "\\\\.\\COM%d", comNumber);
	}
	else {
		sprintf_s(portString, "COM%d", comNumber);
	}


	//printf(portString);
	ShCom = CreateFile(
		portString,									// COM port number  --> If COM# is larger than 9 then use the following syntax--> "\\\\.\\COM10"
		GENERIC_READ | GENERIC_WRITE,				// Open for read and write
		NULL,										// No sharing allowed
		NULL,										// No security
		OPEN_EXISTING,								// Opens the existing com port
		FILE_ATTRIBUTE_NORMAL,						// Do not set any file attributes --> Use synchronous operation
		NULL										// No template
	);

	if (ShCom == INVALID_HANDLE_VALUE) {
		//printf("\nFatal Error 0x%x: Unable to open\n", GetLastError());
	}
	else {
		//printf("\nCOM is now open\n");
	}
}





//***************************************//
//***************************************//
//***************************************//
//************ RECIEVE MESSAGE **********//
void toRecieve() {
	char buffer[sizeof(ANODE)];
	DATA newData = { NULL,NULL };									//initalize a new data to hold the incoming message in
	long check = 0;													//check value to make sure the incoming message has a size
	initRecievePort();												//initalize the recieve port
	
	
	check = inputFromPort(buffer, sizeof(ANODE));					//get the data from the port and save the number of bytes and saves it in the unions character buffer
	newData = messaegConverter.data;										//uses the unions data struct (obtained by the character buffer that was taken in)
	
	
	purgeRecievePort();												//purges the port to be reused
	closeRecieveHandle();												//closes the port to be reused

	
	if (check > 0) {												//only do something if there was a message that was recieved
		printf("\nCHECK:%d\n", check);
		if (check <= sizeof(DATA)) {
			memcpy_s(messaegConverter.buffer, sizeof(DATA), buffer, sizeof(DATA));
			if (messaegConverter.data.frame.recieverAddress == (0x41) || messaegConverter.data.frame.recieverAddress == (0xff)) {		//check the address it was supposed to go to vs this address and the broadcast address
				if (messaegConverter.data.frame.dataType == 0x4D) {
					printf("\nText Message Recieved");
					NODE* newNode = (link)malloc(sizeof(NODE));				//initalize a new node to put in the queue to put the message into
					newData.frame = messaegConverter.data.frame;
					newData.message = messaegConverter.data.message;
					printf("\n\n%d\n\n", newData.message.senderID);
					///

					//newData = converter.data;										//uses the unions data struct (obtained by the character buffer that was taken in)
					//uncompress message here
					int can_compress = GetPrivateProfileInt("Messaging", "canCompress", 0, ".\\settings.txt");
					if (can_compress == 1) {
						char uncompressedMessage[BUFSIZE];
						RLE_Uncompress((unsigned char*)newData.message.message, (unsigned char*)uncompressedMessage, newData.frame.compressed_length);
						memcpy_s(newData.message.message, BUFSIZE, uncompressedMessage, sizeof(uncompressedMessage));
						printf("OLD MESSAGE SIZE %d, NEW MESSAGE SIZE:%d", BUFSIZE, newData.frame.compressed_length);
					}
					//end of uncompression

					//CRC HERE
					if (GetPrivateProfileInt("Messaging", "errorDetect", 0, ".\\settings.txt")) {
						uint32_t newCode = crc32c(0, (unsigned char*)newData.message.message, sizeof(newData.message.message));
						printf("\nThe received CRC code is: %d", newCode);
						printf("\nNo errors: %s", (newCode == newData.frame.CRC_code) ? "true" : "false");
					}

					//CRC HERE

					newNode->data = newData;								//put the incoming messages data into the node
					recieveQ.Push(newNode);									//push the node onto the queue
					addPhonebookEntry(newData.message.senderID);
					HeapNode h;
					strcpy_s(h.message, newData.message.message);
					h.priority = newData.message.priority;
					Heap.insertKey(h);
				}
				else if (messaegConverter.data.frame.dataType == 0xff) {								//VoteOn diagnostics section
					printf("\nDiagnostic Message Recieved\n");
					voteOn[voteOnCounter] = messaegConverter.data.frame;
					voteOnCounter++;

					if (voteOnCounter == 3) {
						FRAME* holder[] = { &voteOn[0], &voteOn[1], &voteOn[2] };
						int bestHeader = VoteOn((void**) holder, 3, sizeof(FRAME));	
						printf("\nBest Header: ");
						printHeader(voteOn[bestHeader]);
						voteOnCounter = 0;
					}
				}
			}
			else {
				printf("\n\n not the right reciever\n\n");
			}
		}
		if(check <= sizeof(ADATA) && check > sizeof(DATA)){
			printf("\nAudio Message Recieved");
			memcpy_s(audioConverter.buffer, sizeof(ADATA), buffer, sizeof(ADATA));
			if (audioConverter.data.frame.recieverAddress == (0x41) || audioConverter.data.frame.recieverAddress == (0xff)) {		//check the address it was supposed to go to vs this address and the broadcast address
				if (audioConverter.data.frame.recieverAddress == 0x41) {
					//audio
					ANODE* newANode = (aLink)malloc(sizeof(ANODE));
					newANode->data = audioConverter.data;
					audioRecieveQ.Push(newANode);
				}
			}
			else {
				printf("\n\n not the right reciever\n\n");
			}
		}
	}
}



void initRecievePort() {
	createRecievePortFile();								// Initializes hCom to point to PORT4 (port 4 is used by USB-Serial adapter on my laptop)
	purgeRecievePort();										// Purges the COM port
	SetComParms(RhCom);										// Uses the DCB structure to set up the COM port
	purgeRecievePort();										// Purges the COM port
}

void createRecievePortFile() {
	// Call the CreateFile() function 
	//string parsing
	int comNumber = GetPrivateProfileInt("Messaging", "RxId", -1, ".\\settings.txt");
	//printf("%d", comNumber);
	char portString[128];
	if (comNumber > 9) {
		sprintf_s(portString, "\\\\.\\COM%d", comNumber);
	}
	else {
		sprintf_s(portString, "COM%d", comNumber);
	}

	//printf(portString);
	// Call the CreateFile() function 
	RhCom = CreateFile(
		portString,									// COM port number  --> If COM# is larger than 9 then use the following syntax--> "\\\\.\\COM10"
		GENERIC_READ | GENERIC_WRITE,				// Open for read and write
		NULL,										// No sharing allowed
		NULL,										// No security
		OPEN_EXISTING,								// Opens the existing com port
		FILE_ATTRIBUTE_NORMAL,						// Do not set any file attributes --> Use synchronous operation
		NULL										// No template
	);

	if (RhCom == INVALID_HANDLE_VALUE) {
		//printf("\nFatal Error 0x%x: Unable to open port %d\n", GetLastError(), comNumber);
	}
	else {
		//printf("\nCOM is now open\n");
	}
}





//*********************************//
//*********************************//
//*********************************//
//************ COMM PORT **********//
static int SetComParms(HANDLE hCom) {
	DCB dcb;										// Windows device control block
	// Clear DCB to start out clean, then get current settings
	memset(&dcb, 0, sizeof(dcb));
	dcb.DCBlength = sizeof(dcb);
	if (!GetCommState(hCom, &dcb))
		return(0);

	// Set our own parameters from Globals
	dcb.BaudRate = nComRate;						// Baud (bit) rate
	dcb.ByteSize = (BYTE)nComBits;					// Number of bits(8)
	dcb.Parity = 0;									// No parity	
	dcb.StopBits = ONESTOPBIT;						// One stop bit
	if (!SetCommState(hCom, &dcb))
		return(0);

	// Set communication timeouts (SEE COMMTIMEOUTS structure in MSDN) - want a fairly long timeout
	memset((void*)& timeout, 0, sizeof(timeout));
	timeout.ReadIntervalTimeout = 500;				// Maximum time allowed to elapse before arival of next byte in milliseconds. If the interval between the arrival of any two bytes exceeds this amount, the ReadFile operation is completed and buffered data is returned
	timeout.ReadTotalTimeoutMultiplier = 1;			// The multiplier used to calculate the total time-out period for read operations in milliseconds. For each read operation this value is multiplied by the requested number of bytes to be read
	timeout.ReadTotalTimeoutConstant = 50;		// A constant added to the calculation of the total time-out period. This constant is added to the resulting product of the ReadTotalTimeoutMultiplier and the number of bytes (above).
	SetCommTimeouts(hCom, &timeout);
	return(1);
}

long inputFromPort(LPVOID buf, DWORD szBuf) {
	int i = 0;
	DWORD NumberofBytesRead;
	LPDWORD lpErrors = 0;
	LPCOMSTAT lpStat = 0;

	i = ReadFile(
		RhCom,										// Read handle pointing to COM port
		buf,										// Buffer size
		szBuf,  									// Size of buffer - Maximum number of bytes to read
		&NumberofBytesRead,
		NULL
	);
	// Handle the timeout error
	if (i == 0) {
		//printf("\nRead Error: 0x%x\n", GetLastError());
		ClearCommError(RhCom, lpErrors, lpStat);		// Clears the device error flag to enable additional input and output operations. Retrieves information ofthe communications error.
	}
	else
		//printf("\nSuccessful reception!, There were %ld bytes read\n", NumberofBytesRead);
		return NumberofBytesRead;
}

// Output message to port
void outputToPort(LPCVOID buf, DWORD szBuf) {
	int i = 0;
	DWORD NumberofBytesTransmitted;
	LPDWORD lpErrors = 0;
	LPCOMSTAT lpStat = 0;

	i = WriteFile(
		ShCom,										// Write handle pointing to COM port
		buf,										// Buffer size
		szBuf,										// Size of buffer
		&NumberofBytesTransmitted,					// Written number of bytes
		NULL
	);
	// Handle the timeout error
	if (i == 0) {
		printf("\nWrite Error: 0x%x\n", GetLastError());
		ClearCommError(ShCom, lpErrors, lpStat);		// Clears the device error flag to enable additional input and output operations. Retrieves information ofthe communications error.	
	}
	//else
		printf("\nSuccessful transmission, there were %ld bytes transmitted\n", NumberofBytesTransmitted);
}

// Purge any outstanding requests on the serial port (initialize)
void purgePort(HANDLE hCom) {
	PurgeComm(hCom, PURGE_RXABORT | PURGE_RXCLEAR | PURGE_TXABORT | PURGE_TXCLEAR);
}


void purgeSendPort() {
	purgePort(ShCom);
}

void purgeRecievePort() {
	purgePort(RhCom);
}

void closeSendHandle()
{
	CloseHandle(ShCom);
}

void closeRecieveHandle()
{
	CloseHandle(RhCom);
}

void ErrorCorrect()
{

	FRAME newFrame;													//frame setup
	newFrame.dataLength = dataLength;
	newFrame.pattern = pattern;
	newFrame.recieverAddress = (unsigned char)GetPrivateProfileInt("Messaging", "ReceiverAddress", 0, ".\\settings.txt");
	newFrame.signature = signature;
	newFrame.version = version;
	newFrame.dataType = 0xff;

	MESSAGE message = {};

	DATA data = {newFrame, message};

	printf("\nShould recieve header: ");
	printHeader(newFrame);

	for (int i = 0; i < 3; i++)
	{	
		if (i == 1 || i == 1) {
			data.frame.pattern = 0x51;
		}
		else {
			data.frame.pattern = pattern;
		}
		NODE* newNode = (link)malloc(sizeof(NODE));
		newNode->data = data;

		sendQ.Push(newNode);
		Sleep(500);
	}
	DisplayMessagingMenu();
}


void printHeader(FRAME frame) {
	printf("\nSignature:              %lx\nReciever Address:       %lx\nVersion:                %c\nData Length:            %ul\nCompressed Data Length: %d\nData Type:              %c\nPattern:                %c\n",
		frame.signature,
		frame.recieverAddress,
		frame.version,
		frame.dataLength,
		frame.compressed_length,
		frame.dataType,
		frame.pattern);
}
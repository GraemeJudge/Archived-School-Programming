/* Queue.cpp

   This is a cpp file containing all of the spporting functions for the queue

	Authors: Stephane Durette, Graeme Judge, Rushi Patil
	Date: October 9, 2019
	Change Log:
		Oct 9, 2019 - Source file created
*/



#include"queue.h"
#include"crc.h"

union messageConverter {													//union to be used to convert the data to a character buffer to be sent
	DATA data;														//the DATA struct to be used in the union
	char buffer[sizeof(DATA)];										//the character buffer to be used for the union
} messageConverter;


		queue::queue() {
			InitQueue();
		}

		void queue::InitQueue() {
			head = tail = NULL;					//Sets head and tail to NULL inititally since theres nothing to point at
		}

		void queue::Push(NODE* node) {
			if (head == NULL) {
				head = tail = node;
			}
			else {
				tail->pNext = node;
			}
			node->pNext = NULL;
			tail = node;
		}

		NODE* queue::Pop() {
			if (head == NULL) {
				return NULL;
			}
			NODE* temp = head;
			head = head->pNext;
			return temp;
		}

		int queue::IsQueueEmpty() {
			if (head == NULL) { return 1; }
			return 0;
		}

		void queue::PrintContents() {
			NODE* p = head;
			while (p != NULL) {
				printf("[%s]", (p->data.message.message));
				p = p->pNext;
			};
			printf("Message Printing Complete\n");
		}

		void queue::PrintMessage(link h) {
			if (h->data.message.message != NULL) {
				printf("\nmessage: %s\n", h->data.message.message);
			}
		}

		void queue::traverse(link h, void (*f)(link h)) {
			if (h == NULL) {
				return;
			}
			(*f) (h);
			traverse(h->pNext, f);
		}

		void queue::traverseR(link h, void (*f)(link h)) {
			if (h == NULL) {
				return;
			}

			traverseR(h->pNext, f);
			(*f)(h);

		}

		link queue::getHead() {

			return head;
		}

		link queue::deleteR(link parent, link child, MESSAGE v) {
			if (child == NULL) return NULL;
			if (child->data.message.senderID == v.senderID) {
				parent->pNext = child->pNext;
				free(child);
				return deleteR(parent, parent->pNext, v);
			}
			else {
				return deleteR(child, child->pNext, v);
			}
		}


		int queue::getCount()
		{
			int count = 0; // Initialize count  
			link current = getHead(); // Initialize current  
			while (current != NULL)
			{
				count++;
				current = current->pNext;
			}
			return count;
		}

		void queue::printNode(int number, boolean withFrame) {
			if (number <= getCount()) {
				link holder = getHead();
				for (int i = 0; i < number - 1; i++)
				{
					holder = holder->pNext;
				}
	
				messageConverter.data = holder->data;
				if (withFrame) {
					printf("\nFrame for message number %d:", number);
					printf("\nSignature:          %lx\nReciever Address:   %lx\nVersion:            %c\nData Length:        %lx\nData Type:          %c\nCrc Code:\t%d\nNew crc code:\t%d\n\nPattern:            %c",
						messageConverter.data.frame.signature,
						messageConverter.data.frame.recieverAddress,
						messageConverter.data.frame.version,
						messageConverter.data.frame.dataLength,
						messageConverter.data.frame.dataType,
						messageConverter.data.frame.CRC_code,
						crc32c(0, (unsigned char*)messageConverter.data.message.message, sizeof(messageConverter.data.message.message)),
						messageConverter.data.frame.pattern);

					//print here errors

				}
				printf("\nMessage:            %s\n\n\n", messageConverter.data.message.message);
			}
		}

		void queue::deleteNode(int number) {
			if (number <= getCount() && number > 0) {
				link holder = getHead();

				if (number == 1) {
					head = holder->pNext;
					free(holder);
					return;
				}
				else {
					for (int i = 1; i < number - 1; i++)
					{
						holder = holder->pNext;
					}
					if (holder->pNext->pNext == NULL){
						free(holder->pNext);
						holder->pNext = NULL;
						tail = holder->pNext;
						return;
					}
					else {
						link temp = holder->pNext;
						holder->pNext = temp->pNext;
						free(temp);
						return;
					}
				
				}
			}
		}

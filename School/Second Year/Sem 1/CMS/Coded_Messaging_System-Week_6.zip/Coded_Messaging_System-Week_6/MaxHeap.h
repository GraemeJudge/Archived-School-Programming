// A C++ program to demonstrate common Binary Heap Operations 
#include<climits> 
#include "queue.h"
using namespace std;

struct HeapNode {
	char message[512];
	int priority;
};

// Prototype of a utility function to swap two integers 
void swap(HeapNode* x, HeapNode* y);

// A class for Min Heap 
class MaxHeap
{
	HeapNode* harr; // pointer to array of elements in heap 
	int capacity; // maximum possible size of min heap 
	int heap_size; // Current number of elements in min heap 

public:
	// Constructor 
	MaxHeap(int capacity);

	// to heapify a subtree with the root at given index 
	void MaxHeapify(int);

	int parent(int i) { return (i - 1) / 2; }

	// to get index of left child of node at index i 
	int left(int i) { return (2 * i + 1); }

	// to get index of right child of node at index i 
	int right(int i) { return (2 * i + 2); }

	// to extract the root which is the minimum element 
	HeapNode extractMax();

	// Decreases key value of key at index i to new_val 
	void decreaseKey(int i, HeapNode new_val);

	// Returns the minimum key (key at root) from min heap 
	HeapNode getMax() { return harr[0]; }

	// Deletes a key stored at index i 
	void deleteKey(int i);

	// Inserts a new key 'k' 
	void insertKey(HeapNode m);

	void printContents();
};

#pragma once
/* VoteOn.h: Interface for Lab 5 - Error Detection and Correction
	By Stephane Durette
*/

//Function Prototypes
int VoteOn(void** Instances, int nInstances, int nSize);

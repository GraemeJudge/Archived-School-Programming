#include "crc.h"

#define POLY 0x82f63b78

uint32_t crc32c(uint32_t crc, const unsigned char* buf, size_t len) {
	crc = ~crc;
	while (len--) {
		crc ^= *buf++;
		for (int k = 0; k < 8; k++) {
			crc = crc & 1 ? (crc >> 1) ^ POLY : crc >> 1;
		}
	}
	return ~crc;
}
#include "VoteOn.h"
#include <string.h>


/* VoteOn.h: Implementation for Lab 5 - Error Detection and Correction
	By Stephane Durette
*/

int VoteOn(void** Instances, int nInstances, int nSize) {
	//int* sumArray = (int*)calloc(nInstances, sizeof(int));
	int sum = 0;
	int maxIndex = -1;
	int maxValue = 0;

	for (int i = 0; i < nInstances; i++) {
		sum = 0;
		for (int j = i + 1; j < nInstances; j++) {
			if (memcmp(Instances[i], Instances[j], nSize) == 0) {
				sum++;
			}
		}
		if (sum > maxValue) {
			maxValue = sum;
			maxIndex = i;
		}
	}

	return maxIndex;
}

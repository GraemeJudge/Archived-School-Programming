#include "phonebook_menu.h"
#include "phonebook.h"
#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "windowsMessaging.h"

static senderInfo Phonebook[Max_ID];					//Last valid address is FE

void InitPhonebook() {
	for (int i = 0; i < Max_ID; i++) {
		Phonebook[i].msgCount = 0;
	}
}

void addPhonebookEntry(short senderID) {
	Phonebook[senderID].msgCount++;
	Phonebook[senderID].lastMessageTime = time(NULL);
}

void DisplayContents() {
	for (int i = 0; i < Max_ID; i++) {
		if (Phonebook[i].msgCount > 0) {
			char buf[512];
			ctime_s(buf, 512, &Phonebook[i].lastMessageTime);
			printf("Sender ID: %d\tSent Messages: %d\tTimestamp:%s\n", i,Phonebook[i].msgCount, buf);
		}
	}
}

#pragma once
void DisplayMessagingSettingsMenu();

void DisplayAudioSettingsMenu();

void Set_Tx();
void Set_Rx();

void SetSinglePort();

void ChangeRecordTime();

void ChangeSampleRate();

void changeGenericIntValue(char section[], char key[], char name[], int minValue, int maxValue);

void Change_Priority();
void Change_SenderID();
void Change_ReceiverAddress();
void Change_Compress_Flag();
void Change_Error_Flag();
/* Queue.h

   This is a header file that contains the definitions for
   all the functions and structures
   implemented by queue.cpp

	Authors: Stephane Durette, Graeme Judge, Rushi Patil
	Date: October 8, 2019
	Change Log:
		Oct 8, 2019 - Source file created
*/

#pragma once
/*
	Header files needed
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "frame.h"
#include "sound.h"



//Global Variables
#define MAX_QUOTE_LENGTH 140
#define AUDIO_LENGTH 80000

//Structures
typedef struct node NODE;	
typedef struct audioNode ANODE;	
typedef struct audio AUDIO;
typedef struct message MESSAGE;
typedef struct node* link;
typedef struct audioNode* aLink;


struct message {					//Holds the needed data for the printing of the message as well as send recieve data
	char message[MAX_QUOTE_LENGTH];
	short senderID;
	short receiverID;
	char priority;
	short seqNum;
	char toBeDefined[25];
};

struct audio {					//Holds the needed data for the printing of the message as well as send recieve data
	char message[(RECORD_TIME * SAMPLES_SEC) * 2];
	short senderID;
	short receiverID;
	char priority;
	short seqNum;
	char toBeDefined[25];
};


struct DATA {
	FRAME frame;
	message message;
};

struct ADATA {
	FRAME frame;
	audio audio;
};

struct node {						//Nodes to be used in the queue holding the message and the next node pointer
	link pNext;
	DATA data;
};

struct audioNode {						//Nodes to be used in the queue holding the message and the next node pointer
	aLink pNext;
	ADATA data;
};

//convert the nodes data into a character pointer and use a union to pass in the needed data to it to allow for 
//audio or text and have seperate queues for recieing of them to keep it easier to handle (means alot of changes but should be manageable)


//******MESSAGE QUEUE*******//
class queue {
public:

	NODE* head;
	NODE* tail;

	queue();


	/*
		void InitQueue( void );

		Initializes the queue by setting the head and tail node* to null;

		Input: None
		Output: None
	*/
	void InitQueue(void);

	/*
		void Push(NODE* node);

		appends a node* object to the queue.

		Input: NODE* node
				the node object to append to the queue.
		Output: None
	*/
	void Push(NODE* node);

	/*
		NODE *Pop( void );

		returns the first item in the queue and removes it from the linked list.

		Input: None
		Output: Node* that was popped off the linked list
	*/
	NODE* Pop(void);

	/*
		int IsQueueEmpty( void );

		Checks if the queue is empty

		Input: None
		Output:
			1 if the queue is empty
			0 if the queue is not empty
	*/
	int IsQueueEmpty(void);

	/*
		void PrintContents();

		Prints all of the messages in the queue in order

		Input: None
		Output None
	*/
	void PrintContents();


	/*
		void PrintMessage();

		Prints the message of a given node

		Input: link h
				The pointer to the node whose message is to be printed
		Output None
	*/
	void PrintMessage(link h);

	//new stuff for assignment 2

	/*
		void traverse(link h, void(*f)(link h));

		This function recusively traverses through the queue. Calls a function f
		with the current link as an argument and calls itself with the next link.
		This stops when the current link is null.

		Input: link h
				a pointer to the head node of the queue
		Input: void(*f)(link h)
				a pointer to a function that takes a node* as an argument
	*/
	void traverse(link h, void (*f)(link h));

	/*
		void traverseR(link h, void(*f)(link h));

		This function does exactly what traverse does except it
		calls itself before calling the function. Which causes the function
		calls to happen in reverse order which simulates a backward traversal
		through the list

		Input: link h
				a pointer to the head node of the queue
		Input: void(*f)(link h)
				a pointer to a function that takes a node* as an argument
	*/
	void traverseR(link h, void (*f)(link h));

	/*
		link getHead();

		This function returns a pointer to the first node in the queue.

		Input: None
		Output: node* representing the first node in the queue.
	*/
	link getHead();

	/*
		link deleteR(link parent, link child, MESSAGE v);

		This function deletes all nodes in a queue where the senderid is equal to
		v's sending id.

		Input: link parent
				the link before the link being checked
		Input: link child
				the link being checked
		Input: MESSAGE v
				if the node contains this message, it must be removed from the queue.

		Output: None
	*/
	link deleteR(link parent, link child, MESSAGE v);


	/*
	void getCount;

	Returns the number of nodes in the queue

	Input: None
	Output: integer represeting the number of nodes
	*/
	int getCount();

	/*
	void printNode;

	Prints the specified node out

	Input: int number
				message number to print
		   boolean withFrame
				wether or not to print the header fram as well
	Output: None
	*/
	void printNode(int number, boolean withFrame);

	/*
	void deleteNode;

	Deletes the specified node in the list

	Input: int number
				the message number to delete
	Output: None
	*/
	void deleteNode(int number);

	};

//******AUDIO QUEUE*******//
class audioQueue {
public:

	ANODE* head;
	ANODE* tail;

	audioQueue();


	/*
		void InitQueue( void );

		Initializes the queue by setting the head and tail node* to null;

		Input: None
		Output: None
	*/
	void InitQueue(void);

	/*
		void Push(NODE* node);

		appends a node* object to the queue.

		Input: NODE* node
				the node object to append to the queue.
		Output: None
	*/
	void Push(ANODE* node);

	/*
		NODE *Pop( void );

		returns the first item in the queue and removes it from the linked list.

		Input: None
		Output: Node* that was popped off the linked list
	*/
	ANODE* Pop(void);

	/*
		int IsQueueEmpty( void );

		Checks if the queue is empty

		Input: None
		Output:
			1 if the queue is empty
			0 if the queue is not empty
	*/
	int IsQueueEmpty(void);

	/*
		void PrintContents();

		Prints all of the messages in the queue in order

		Input: None
		Output None
	*/
	void PrintContents();


	/*
		void PrintMessage();

		Prints the message of a given node

		Input: link h
				The pointer to the node whose message is to be printed
		Output None
	*/
	void PrintMessage(aLink h);

	//new stuff for assignment 2

	/*
		void traverse(link h, void(*f)(link h));

		This function recusively traverses through the queue. Calls a function f
		with the current link as an argument and calls itself with the next link.
		This stops when the current link is null.

		Input: link h
				a pointer to the head node of the queue
		Input: void(*f)(link h)
				a pointer to a function that takes a node* as an argument
	*/
	void traverse(aLink h, void (*f)(aLink h));

	/*
		void traverseR(link h, void(*f)(link h));

		This function does exactly what traverse does except it
		calls itself before calling the function. Which causes the function
		calls to happen in reverse order which simulates a backward traversal
		through the list

		Input: link h
				a pointer to the head node of the queue
		Input: void(*f)(link h)
				a pointer to a function that takes a node* as an argument
	*/
	void traverseR(aLink h, void (*f)(aLink h));

	/*
		link getHead();

		This function returns a pointer to the first node in the queue.

		Input: None
		Output: node* representing the first node in the queue.
	*/
	aLink getHead();

	/*
		link deleteR(link parent, link child, MESSAGE v);

		This function deletes all nodes in a queue where the senderid is equal to
		v's sending id.

		Input: link parent
				the link before the link being checked
		Input: link child
				the link being checked
		Input: MESSAGE v
				if the node contains this message, it must be removed from the queue.

		Output: None
	*/
	aLink deleteR(aLink parent, aLink child, AUDIO v);


	/*
	void getCount;

	Returns the number of nodes in the queue

	Input: None
	Output: integer represeting the number of nodes
	*/
	int getCount();

	/*
	void printNode;

	Prints the specified node out

	Input: int number
				message number to print
			boolean withFrame
				wether or not to print the header fram as well
	Output: None
	*/
	void printNode(int number, boolean withFrame);

	/*
	void deleteNode;

	Deletes the specified node in the list

	Input: int number
				the message number to delete
	Output: None
	*/
	void deleteNode(int number);



	aLink getNode(int number);

};
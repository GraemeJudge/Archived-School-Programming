/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/
#include "queue.h"
#include "menu.h"





void printAndDeleteAll();

void DisplayInboxMenu();

void deleteMessage();

void printMessage();

void printAll();

/*
	void countMessages;

	prints te number of messages in the queue

	Input: None
	Output: None
*/
void countMessages();




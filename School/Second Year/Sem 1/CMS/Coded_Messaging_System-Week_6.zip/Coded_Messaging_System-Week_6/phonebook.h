//#include "treefunc.h"
//
//void InitPhonebook();
//void SetPhonebookActive(bool active);
//void PhonebookInsert(DATA d);
//void PhonebookPrintAllMessages();
//int PhonebookRetrieveMessages(char** messageList, long int senderID); //returns the amount of messages

/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/
#include "queue.h"


extern audioQueue audioRecieveQ;					//queue to hold the audio items that have been recieved (not being used);
extern audioQueue audioSendQ;						//queue to hold the audio items that are waiting to be sent


/*
	void DisplayAudioMenu;

	Displays the audio menu

	Input: None
	Output: None
*/
void DisplayAudioMenu();

/*
	void recordAndPlay;

	Records the set amount of time from the microphone 
	then plays it back before proceeding

	Input: None
	Output: None
*/
void recordAndPlay();

/*
	int saveToFile;

	Saves the given audio buffer to a .dat file

	Input:	short* iBugBuf 
				The audio data to be saved
			long 1BigBufSize
				The length of the audio data to be stored
	Output: int
				Returns an integer representing if the save was sucessful or not
				1 - Error
				0 - Successful
*/
int saveToFile(short* iBigBuf, long lBigBufSize);

/*
	void playFromFile;

	Plays the saved audio file no matter the length

	Input: None
	Output: None
*/
void playFromFile();

/*
	void ChangeSettings; (to-do)

	Opens the settings menu and allow you to change them 

	Input: None
	Output: None
*/
void ChangeSettings();

/*
	int getAudioLength;

	Gets the length of the saved audio file before playing it back

	Input:  FILE* fp
				Pointer to the open file being read
	Output: int
				Retruns the length of the file in seconds as an integer
*/
int getAudioLength(FILE* fp);




void audioSend();

void recordAndSend();

void enqueueForSend(short* buffer);
/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/
#if defined(_WIN32)
	#define PLATFORM_NAME "windows" // Windows
	#include <windows.h>
#elif defined(_WIN64)
	#define PLATFORM_NAME "windows" // Windows
#elif defined(__linux__)
	#define PLATFORM_NAME "linux"
#endif
//Structs
typedef struct mc MenuChoice;


//function prototypes
void DisplayMenu();
void DisplayTempMenu(char title[], MenuChoice* options, int size);
void NotImplemented();
void exit();


//struct definitions
struct mc {
	char name[140];
	void (*action)(void);
};

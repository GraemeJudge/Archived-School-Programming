#include "MaxHeap.h"
/*
struct message {					//Holds the needed data for the printing of the message as well as send recieve data
char message[MAX_QUOTE_LENGTH];
short senderID;
short receiverID;
char priority;
short seqNum;
char toBeDefined[25];
};
*/
MaxHeap::MaxHeap(int cap)
{
	heap_size = 0;
	capacity = cap;
	harr = new HeapNode[cap];
}

// Inserts a new key 'k' 
void MaxHeap::insertKey(HeapNode m)
{
	if (heap_size == capacity){
		return;
	}

	// First insert the new key at the end 
	heap_size++;
	int i = heap_size - 1;
	harr[i] = m;

	// Fix the min heap property if it is violated 
	while (i != 0 && harr[parent(i)].priority < harr[i].priority)
	{
		swap(&harr[i], &harr[parent(i)]);
		i = parent(i);
	}
}

// Decreases value of key at index 'i' to new_val.  It is assumed that 
// new_val is smaller than harr[i]. 
void MaxHeap::decreaseKey(int i, HeapNode new_val)
{
	harr[i] = new_val;
	while (i != 0 && harr[parent(i)].priority < harr[i].priority)
	{
		swap(&harr[i], &harr[parent(i)]);
		i = parent(i);
	}
}

// Method to remove minimum element (or root) from min heap 
HeapNode MaxHeap::extractMax()
{
	if (heap_size <= 0) {
		HeapNode m;
		m.priority = -1;
		return m;
	}
	if (heap_size == 1)
	{
		heap_size--;
		return harr[0];
	}

	// Store the minimum value, and remove it from heap 
	HeapNode root = harr[0];
	harr[0] = harr[heap_size - 1];
	heap_size--;
	MaxHeapify(0);

	return root;
}


// This function deletes key at index i. It first reduced value to minus 
// infinite, then calls extractMin() 
void MaxHeap::deleteKey(int i)
{
	HeapNode m;
	m.priority = -1;

	decreaseKey(i, m);
	extractMax();
}

void MaxHeap::printContents() {
	int sz = heap_size;
	HeapNode* temp = (HeapNode*)calloc(sz, sizeof(HeapNode));
	for (int i = 0; i < sz; i++) {
		HeapNode m = extractMax();
		printf("Priority:\t%d\nMessage:\t%s\n", m.priority, m.message);
		temp[i] = m;
	}
	for (int i = 0; i < sz; i++) {
		insertKey(temp[i]);
	}
}

// A recursive method to heapify a subtree with the root at given index 
// This method assumes that the subtrees are already heapified 
void MaxHeap::MaxHeapify(int i)
{
	int l = left(i);
	int r = right(i);
	int biggest = i;
	if (l < heap_size && harr[l].priority > harr[i].priority)
		biggest = l;
	if (r < heap_size && harr[r].priority > harr[biggest].priority)
		biggest = r;
	if (biggest != i)
	{
		swap(&harr[i], &harr[biggest]);
		MaxHeapify(biggest);
	}
}

// A utility function to swap two elements 
void swap(HeapNode* x, HeapNode* y) {
	HeapNode temp = *x;
	*x = *y;
	*y = temp;
}

#include "sound.h"
#include "queue.h"
#include "menu.h"
#include "windowsAudio.h"
#include "windowsMessaging.h"
#include "settings.h"
#include <windows.h>

static MenuChoice audioOptions[] = {
	{"Change Recording Duration", &ChangeRecordTime},
	{"Change Sample Rate", &ChangeSampleRate},
	{"Set Compress Flag", &Change_Compress_Flag},
	{"Back", &DisplayAudioMenu},
	{"Back to main menu", &DisplayMenu},
};

static MenuChoice messagingOptions[] = {
	{"Set Tx", &Set_Tx},
	{"Set Rx", &Set_Rx},
	{"Set single port", &SetSinglePort},
	{"Change Message Size", &ChangeSampleRate},
	{"Back", &DisplayMessagingMenu},
	{"Change Message Priority", &Change_Priority},
	{"Change Sender ID", &Change_SenderID},
	{"Change Receiver Address", &Change_ReceiverAddress},
	{"Set Compress Flag", &Change_Compress_Flag},
	{"Set Error Flag", &Change_Error_Flag},
	{"Back to main menu", &DisplayMenu},
};

void DisplayAudioSettingsMenu() {
	char title[] = "Settings Menu";
	int n = sizeof(audioOptions) / sizeof(MenuChoice);
	DisplayTempMenu(title, audioOptions, n);
}

void changeGenericIntValue(char section[], char key[], char name[], int minValue, int maxValue) {
	int current = GetPrivateProfileInt(section, key, 0, ".\\settings.txt");
	printf("Current %s: %d\n",name , current);

	char buf[1024];
	int userInput;
	do {
		printf("\nEnter a Valid %s: ", name);
		fgets(buf, 1024, stdin);
		userInput = atoi(buf);
	} while (userInput < minValue || userInput > maxValue);
	WritePrivateProfileString(section, key, buf, "./settings.txt");
	printf("\n %s is now: %d\n", name, userInput);
}

void Change_Compress_Flag() {
	char section[] = "Messaging";
	char key[] = "canCompress";
	char message[] = "Compression Flag (1 = On, 0 = Off)";
	changeGenericIntValue(section, key, message, 0, 1);
}

void Change_Error_Flag() {
	char section[] = "Messaging";
	char key[] = "errorDetect";
	char message[] = "Error detect flag (1 = On, 0 = Off)";
	changeGenericIntValue(section, key, message, 0, 1);
}

void Change_Priority() {
	char section[] = "Messaging";
	char key[] = "Priority";
	changeGenericIntValue(section, key, key, 1, 5);
}

void Change_SenderID() {
	char section[] = "Messaging";
	char key[] = "SenderID";
	changeGenericIntValue(section, key, key, 0, 254);
	set_sender_id();
}

void Change_ReceiverAddress() {
	char section[] = "Messaging";
	char key[] = "ReceiverAddress";
	char name[] = "Receiver Address";
	changeGenericIntValue(section, key, name, 0, 255);
}

void Set_Tx() {
	char buf[1024];
	int userInput;
	do {
		printf("\nEnter a valid COM port number: ");
		fgets(buf, 1024, stdin);
		userInput = atoi(buf);
	} while (userInput < 0 || userInput > 100);
	WritePrivateProfileString("Messaging","TxId",buf,"./settings.txt");
	printf("\nTx is now: COM%s", buf);
}

void Set_Rx() {
	char buf[1024];
	int userInput;
	do {
		printf("\nEnter a valid COM port number: ");
		fgets(buf, 1024, stdin);
		userInput = atoi(buf);
	} while (userInput < 0 || userInput > 100);
	WritePrivateProfileString("Messaging", "RxId", buf, "./settings.txt");
	printf("\nRx is now: COM%s", buf);
}

void SetSinglePort() {
	running = false;
	Sleep(1000);
	setUpRecieving();
}

void DisplayMessagingSettingsMenu() {
	char title[] = "Settings Menu";
	int n = sizeof(messagingOptions) / sizeof(MenuChoice);
	DisplayTempMenu(title, messagingOptions, n);
}

void ChangeRecordTime() {
	NotImplemented();
}

void ChangeSampleRate() {
	NotImplemented();
}
void InitPhonebook();
void SetPhonebookActive(bool active);
void PhonebookInsert(char* message, long int senderID);
int PhonebookRetrieveMessages(char** messageList, long int senderID); //returns the amount of messages

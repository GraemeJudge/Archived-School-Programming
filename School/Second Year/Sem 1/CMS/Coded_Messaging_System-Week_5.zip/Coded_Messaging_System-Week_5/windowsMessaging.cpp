/* name.Extension -	Description
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			October 10, 1999: Source file created
*/

#include "windowsMessaging.h"
#include "menu.h"
#include "settings.h"
#include <cstdio>
#include <stdlib.h>
#include <string.h>




#define EX_FATAL 1
#define BUFSIZE 140

#define SENDCOMPORT	"\\\\.\\COM15"
#define RECIEVECOMPORT "\\\\.\\COM15"

HANDLE hCom;														// Pointer to a COM port
int nComRate = 9600;												// Baud (Bit) rate in bits/second 
int nComBits = 8;													// Number of bits per frame
COMMTIMEOUTS timeout;												// A commtimout struct variable

boolean running = true;												//variable to stop the thread (likely will be changing this one)


union convert {														//union to be used to convert the data to a character buffer to be sent
	DATA data;														//the DATA struct to be used in the union
	char buffer[sizeof(DATA)];										//the character buffer to be used for the union
} converter;														//name of the union



//queues for sending and recieving data
queue sendQ = queue();												//queue to holding messages waiting to send
queue recieveQ = queue();											//queue to hold the messages that have been recieved

std::thread RECIEVE(ThreadedRun, 3000);								//thread for function ThreadedRun with a timeout of 3000 miliseconds

static MenuChoice options[]{										//array of menu options to pick from
	{"Send Message", &sendMessage},
	{"Send Random Fortune", &sendRandomFortune},
	{"Recieve Message", &recieveMessage},
	{"Count Messages", &countMessages},
	{"Change Settings", &DisplayMessagingSettingsMenu},
	{"Back to Main Menu", &DisplayMenu},
	{"Exit", &exit}					
};

void setUpRecieving() {
	RECIEVE.detach();												//makes it so that the prgram wont wait for the thread to finish before moving on
	//RECIEVE.join();												//makes the program wait for the thread to finish (means just the thread will output so we can see it running)
}


void ThreadedRun(int timeout) {
	while (running){
		DATA newData = {NULL,NULL};									//initalize a new data to hold the incoming message in
		long check = 0;												//check value to make sure the incoming message has a size
		initRecievePort();											//initalize the recieve port
		check = inputFromPort(converter.buffer, sizeof(DATA));		//get the data from the port and save the number of bytes and saves it in the unions character buffer
		newData = converter.data;									//uses the unions data struct (obtained by the character buffer that was taken in)
		purgePort();												//purges the port to be reused
		CloseHandle(hCom);											//closes the port to be reused
		if (check > 0) {											//only do something if there was a message that was recieved
			//printf("\nCHECK:%d\n", check);
			NODE* newNode = (link)malloc(sizeof(NODE));				//initalize a new node to put in the queue to put the message into
			newNode->data = newData;								//put the incoming messages data into the node
			recieveQ.Push(newNode);									//push the node onto the queue
		}
		if (!sendQ.IsQueueEmpty()) {								//check if theres a message to send
			tosend();												//send the first message that is waiting to be sent
		}
	}
}


void DisplayMessagingMenu() {
	char title[] = "Messaging Menu";								//title for the menu
	int n = sizeof(options) / sizeof(MenuChoice);					//the number of menu choices that are available to pick from
	DisplayTempMenu(title, options, n);								//display the mneu
}





//***************************************//
//***************************************//
//***************************************//
//************ SEND MESSAGE **********//
void tosend() {	
	initSendPort();													//initalize the send port to send from
	char* mes = sendQ.Pop()->data.message.message;					//get the first messsage waiting to be sent

																	//setup for the frame to be sent 
	long signature = 0xDEADBEEF;									
	char recieverAddress = 0x41;
	char version = 0x42;
	long dataLength = 0xBEEFDEAD;
	char pattern = 0x43;

	FRAME newFrame = {signature,									//frame setup
		recieverAddress, 
		version, 
		dataLength, 
		pattern };

																	//set up for the message tobe sent
	MESSAGE newMessage = {"",0,0,0,0,{0} };
	memcpy_s(newMessage.message, BUFSIZE, mes, strlen(mes));
											
	DATA data = {newFrame, newMessage};								//puts the message and the header together into the data struct
	
	converter.data = data;											//puts the data struct into the union to convert to a character buffer

	outputToPort(converter.buffer, sizeof(DATA));					//sends it to the output port

	Sleep(1000);													//give it a second to make sure it sends

	purgePort();													//purge the port
	CloseHandle(hCom);												//close the port
}

void sendMessage() {
	MESSAGE newMessage = { "",0,0,0,0,{0} };						//initalize a new message from the user

	int userInput;													
	printf("\nEnter a message\n");
	fgets(newMessage.message, 140, stdin);							//gets the users message and stores it in the new messages nessage field

	NODE* newNode = (link)malloc(sizeof(NODE));						//create a new node to put into the sending queue
	if (newNode != NULL) {
		newNode->data.message = newMessage;							//put the message into the node
		sendQ.Push(newNode);										//push the node onto the queue
	}

	printf("\nMessage attempting to send: \n%s\n\n", newMessage.message);

	system("pause");
	DisplayMessagingMenu();
}

void sendRandomFortune() {
	MESSAGE newMessage = { "",0,0,0,0,{0} };						//initalize a new message to store the fortune in to be sent
	int set = 0;													//holder for how many fortunes want to be sent
	char buf[1024];													//buffer to hold the 
	while (set < 1) {
		printf("\nPlease pick a number of fortunes to send: ");		
		fgets(buf, 1024, stdin);
		set = atoi(buf);
	}

	for (int i = 0; i < set; i++)
	{
		GetMessageFromFile(newMessage.message, 140);
		NODE* newNode = (link)malloc(sizeof(NODE));
		if (newNode != NULL) {
			newNode->data.message = newMessage;
			sendQ.Push(newNode);
		}

		printf("\nMessage attempting to send: \n%s\n\n", newMessage.message);
	}
	system("pause");
	DisplayMessagingMenu();

}

// Initializes the port and sets the communication parameters
void initSendPort() {
	createSendPortFile();										// Initializes hCom to point to PORT4 (port 4 is used by USB-Serial adapter on my laptop)
	purgePort();												// Purges the COM port
	SetComParms();												// Uses the DCB structure to set up the COM port
	purgePort();
}

// Set the hCom HANDLE to point to a COM port, initialize for reading and writing, open the port and set securities
void createSendPortFile() {
	// Call the CreateFile() function 
	//string parsing
	int comNumber = GetPrivateProfileInt("Messaging", "TxId", -1, ".\\settings.txt");
	//printf("%d", comNumber);
	char portString[128];
	if (comNumber > 9) {
		sprintf_s(portString, "\\\\.\\COM%d", comNumber);
	}
	else {
		sprintf_s(portString, "COM%d", comNumber);
	}


	//printf(portString);
	hCom = CreateFile(
		portString,									// COM port number  --> If COM# is larger than 9 then use the following syntax--> "\\\\.\\COM10"
		GENERIC_READ | GENERIC_WRITE,				// Open for read and write
		NULL,										// No sharing allowed
		NULL,										// No security
		OPEN_EXISTING,								// Opens the existing com port
		FILE_ATTRIBUTE_NORMAL,						// Do not set any file attributes --> Use synchronous operation
		NULL										// No template
	);

	if (hCom == INVALID_HANDLE_VALUE) {
		//printf("\nFatal Error 0x%x: Unable to open\n", GetLastError());
	}
	else {
		//printf("\nCOM is now open\n");
	}
}





//***************************************//
//***************************************//
//***************************************//
//************ RECIEVE MESSAGE **********//

void recieveMessage() {
	int counter = 1;

	while (!recieveQ.IsQueueEmpty()) {
		converter.data = recieveQ.Pop()->data;
		printf("\nFrame for message number %d:", counter);
		printf("\n%lx\n%c\n%c\n%lx\n%c", 
			converter.data.frame.signature, 
			converter.data.frame.recieverAddress,
			converter.data.frame.version,
			converter.data.frame.dataLength,
			converter.data.frame.pattern);
		printf("\n\nMessage:%s\n\n\n",converter.data.message.message);

		counter++;
	}
}

void countMessages() {
	printf("\nYou have %d new messages\n", recieveQ.getCount());
}

void initRecievePort() {
	createRecievePortFile();								// Initializes hCom to point to PORT4 (port 4 is used by USB-Serial adapter on my laptop)
	purgePort();											// Purges the COM port
	SetComParms();											// Uses the DCB structure to set up the COM port
	purgePort();											// Purges the COM port
}

void createRecievePortFile() {
	// Call the CreateFile() function 
	//string parsing
	int comNumber = GetPrivateProfileInt("Messaging", "RxId", -1, ".\\settings.txt");
	//printf("%d", comNumber);
	char portString[128];
	if (comNumber > 9) {
		sprintf_s(portString, "\\\\.\\ fwM%d", comNumber);
	}
	else {
		sprintf_s(portString, "COM%d", comNumber);
	}

	//printf(portString);
	// Call the CreateFile() function 
	hCom = CreateFile(
		portString,									// COM port number  --> If COM# is larger than 9 then use the following syntax--> "\\\\.\\COM10"
		GENERIC_READ | GENERIC_WRITE,				// Open for read and write
		NULL,										// No sharing allowed
		NULL,										// No security
		OPEN_EXISTING,								// Opens the existing com port
		FILE_ATTRIBUTE_NORMAL,						// Do not set any file attributes --> Use synchronous operation
		NULL										// No template
	);

	if (hCom == INVALID_HANDLE_VALUE) {
		printf("\nFatal Error 0x%x: Unable to open\n", GetLastError());
	}
	else {
		//printf("\nCOM is now open\n");
	}
}





//*********************************//
//*********************************//
//*********************************//
//************ COMM PORT **********//

static int SetComParms() {
	DCB dcb;										// Windows device control block
	// Clear DCB to start out clean, then get current settings
	memset(&dcb, 0, sizeof(dcb));
	dcb.DCBlength = sizeof(dcb);
	if (!GetCommState(hCom, &dcb))
		return(0);

	// Set our own parameters from Globals
	dcb.BaudRate = nComRate;						// Baud (bit) rate
	dcb.ByteSize = (BYTE)nComBits;					// Number of bits(8)
	dcb.Parity = 0;									// No parity	
	dcb.StopBits = ONESTOPBIT;						// One stop bit
	if (!SetCommState(hCom, &dcb))
		return(0);

	// Set communication timeouts (SEE COMMTIMEOUTS structure in MSDN) - want a fairly long timeout
	memset((void*)& timeout, 0, sizeof(timeout));
	timeout.ReadIntervalTimeout = 500;				// Maximum time allowed to elapse before arival of next byte in milliseconds. If the interval between the arrival of any two bytes exceeds this amount, the ReadFile operation is completed and buffered data is returned
	timeout.ReadTotalTimeoutMultiplier = 1;			// The multiplier used to calculate the total time-out period for read operations in milliseconds. For each read operation this value is multiplied by the requested number of bytes to be read
	timeout.ReadTotalTimeoutConstant = 500;		// A constant added to the calculation of the total time-out period. This constant is added to the resulting product of the ReadTotalTimeoutMultiplier and the number of bytes (above).
	SetCommTimeouts(hCom, &timeout);
	return(1);
}

long inputFromPort(LPVOID buf, DWORD szBuf) {
	int i = 0;
	DWORD NumberofBytesRead;
	LPDWORD lpErrors = 0;
	LPCOMSTAT lpStat = 0;

	i = ReadFile(
		hCom,										// Read handle pointing to COM port
		buf,										// Buffer size
		szBuf,  									// Size of buffer - Maximum number of bytes to read
		&NumberofBytesRead,
		NULL
	);
	// Handle the timeout error
	if (i == 0) {
		//printf("\nRead Error: 0x%x\n", GetLastError());
		ClearCommError(hCom, lpErrors, lpStat);		// Clears the device error flag to enable additional input and output operations. Retrieves information ofthe communications error.
	}
	else
		//printf("\nSuccessful reception!, There were %ld bytes read\n", NumberofBytesRead);
		return NumberofBytesRead;
}

// Output message to port
void outputToPort(LPCVOID buf, DWORD szBuf) {
	int i = 0;
	DWORD NumberofBytesTransmitted;
	LPDWORD lpErrors = 0;
	LPCOMSTAT lpStat = 0;

	i = WriteFile(
		hCom,										// Write handle pointing to COM port
		buf,										// Buffer size
		szBuf,										// Size of buffer
		&NumberofBytesTransmitted,					// Written number of bytes
		NULL
	);
	// Handle the timeout error
	if (i == 0) {
		printf("\nWrite Error: 0x%x\n", GetLastError());
		ClearCommError(hCom, lpErrors, lpStat);		// Clears the device error flag to enable additional input and output operations. Retrieves information ofthe communications error.	
	}
	//else
		//printf("\nSuccessful transmission, there were %ld bytes transmitted\n", NumberofBytesTransmitted);
}

// Purge any outstanding requests on the serial port (initialize)
void purgePort() {
	PurgeComm(hCom, PURGE_RXABORT | PURGE_RXCLEAR | PURGE_TXABORT | PURGE_TXCLEAR);
}
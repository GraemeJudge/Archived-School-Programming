/* main.cpp - Main file for testing the Coded Messaging System project
*  By: Graeme Judge, Stephane Durette, Ruchi Patil
*/


#include"queue.h"
#include"sound.h"
#include "menu.h"
#include "windowsMessaging.h"

int main(int argc, char** argv) {
	setUpRecieving();
	DisplayMenu();
}


#pragma once
void DisplayMessagingSettingsMenu();

void DisplayAudioSettingsMenu();

void Set_Tx();
void Set_Rx();
void ChangeRecordTime();

void ChangeSampleRate();
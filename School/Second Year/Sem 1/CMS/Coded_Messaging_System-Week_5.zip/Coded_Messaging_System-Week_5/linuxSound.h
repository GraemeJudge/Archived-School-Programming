/* stream.cpp : Interface for playback / capture of audio streams
 *
 * Copyright 2019 Michael Galle
 */
#if defined(__linux__)
#ifndef AUDIO
#define AUDIO
#include <alsa/asoundlib.h>		// At terminal need to install alsa headers to /usr/include/alsa via installing: $ sudo apt-get install libasound2-dev  

 // Constants (depend on hardware capabilities)
#define SAMPLE_TIME         6       * 4                             // 6 seconds. Total sample/playback time in seconds 
#define SAMPLE_RATE         16384   * 4                             // # of frames (samples) per second - using 65536/4 = 16384 gives 1 buffer/s
#define BYTES_PER_HW_BUF    65536                                   // 2^16 (based on hardware buffer max size)
#define NUM_CHANNELS        2                                       // # of channels (choose 1 for mono, 2 for stereo)
#define BYTES_PER_SAMPLE    2                                       // 16 Bit samples chosen = 2 bytes per sample (frame)
#define PERIODS_PER_HW_BUF  4                                       // # of periods to use in the hardware buffer (use a power of 2) 

// Function prototypes
int prepareStream(snd_pcm_t * *pcm_handle, snd_pcm_stream_t stream, snd_pcm_hw_params_t * *hwparams, char* pcm_name);
long readbuf(snd_pcm_t* handle, char* buf, long len, size_t* frames, size_t* max);
long writebuf(snd_pcm_t* handle, char* buf, long len, size_t* frames);

#endif
#endif
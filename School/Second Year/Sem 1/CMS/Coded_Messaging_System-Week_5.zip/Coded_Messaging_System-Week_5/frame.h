/* frame.h - function prototypes for all of functions used by the frame.cpp and the structure definitions
*
*  		Copyright 2019 Graeme Judge
*		Change Log:
*  			Novemeber 21, 2019: Source file created
*/
#include <windows.h>

//structure to hold the frame information to be sent along with the data
struct FRAME {
	long signature;
	byte recieverAddress;
	byte version;
	long dataLength;
	byte pattern;
};









/* Queue.cpp

   This is a cpp file containing all of the spporting functions for the queue

	Authors: Stephane Durette, Graeme Judge, Rushi Patil
	Date: October 9, 2019
	Change Log:
		Oct 9, 2019 - Source file created
*/



#include"queue.h"


		queue::queue() {
			InitQueue();
		}

		void queue::InitQueue() {
			head = tail = NULL;					//Sets head and tail to NULL inititally since theres nothing to point at
		}

		void queue::Push(NODE* node) {
			if (head == NULL) {
				head = tail = node;
			}
			else {
				tail->pNext = node;
			}
			node->pNext = NULL;
			tail = node;


		}

		NODE* queue::Pop() {
			if (head == NULL) {
				return NULL;
			}
			NODE* temp = head;
			head = head->pNext;
			return temp;
		}

		int queue::IsQueueEmpty() {
			if (head == NULL) { return 1; }
			return 0;
		}

		void queue::PrintContents() {
			NODE* p = head;
			while (p != NULL) {
				printf("[%s]", (p->data.message.message));
				p = p->pNext;
			};
			printf("Message Printing Complete\n");
		}

		void queue::PrintMessage(link h) {
			if (h->data.message.message != NULL) {
				printf("\nmessage: %s\n", h->data.message);
			}
		}

		//Assignemnt 2 additions (traversing)

		void queue::traverse(link h, void (*f)(link h)) {
			if (h == NULL) {
				return;
			}
			(*f) (h);
			traverse(h->pNext, f);
		}


		void queue::traverseR(link h, void (*f)(link h)) {
			if (h == NULL) {
				return;
			}

			traverseR(h->pNext, f);
			(*f)(h);

		}

		link queue::getHead() {

			return head;
		}

		link queue::deleteR(link parent, link child, MESSAGE v) {
			if (child == NULL) return NULL;
			if (child->data.message.senderID == v.senderID) {
				parent->pNext = child->pNext;
				free(child);
				return deleteR(parent, parent->pNext, v);
			}
			else {
				return deleteR(child, child->pNext, v);
			}
		}


		int queue::getCount()
		{
			int count = 0; // Initialize count  
			link current = getHead(); // Initialize current  
			while (current != NULL)
			{
				count++;
				current = current->pNext;
			}
			return count;
		}
#include "queue.h"

//need bst
//need bst node
//edit bst to compare sender ids on insertion
//edit bst to contain nodes
//need to activate this on reception


static bool active;


void InitPhonebook() {
	active = true;
	//init bst
}
void SetPhonebookActive(bool _active) {
	active = _active;
}
void PhonebookInsert(char* message, long int senderID) {

}
int PhonebookRetrieveMessages(char** messageList, long int senderID) {

}
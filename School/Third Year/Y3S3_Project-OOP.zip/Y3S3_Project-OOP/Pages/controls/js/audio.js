var floor1audio = new Audio(); floor1audio.src="../res/1stfloor.mp3";
var floor2audio = new Audio(); floor2audio.src="../res/2ndfloor.mp3";
var floor3audio = new Audio(); floor3audio.src="../res/3rdfloor.mp3";
var goingup = new Audio(); goingup.src = "../res/Goingup.mp3";
var goingdown = new Audio(); goingdown.src = "../res/Goingdown.mp3";
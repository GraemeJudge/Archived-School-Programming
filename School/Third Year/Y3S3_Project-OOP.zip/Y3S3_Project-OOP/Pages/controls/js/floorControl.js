var postReqPrefix = "";

function handleForm(){
	var floor = parseInt(document.forms["form1"]["fsel"].value);
	if(floor <1){
		floor = 1;
	}else if(floor >3){
		floor = 3;
	}else if(floor == null){
		return;
	}
	document.getElementById("floorDisplay").innerHTML = floor;
}

function goDown(CFL){
	getRequest(postReqPrefix + "floorCall.php", "Des_Floor", CFL, function handle(retVal){});
	document.getElementById("elevatordir").innerHTML = "Going Down";
}

function goUp(CFL){
	getRequest(postReqPrefix + "floorCall.php", "Des_Floor", CFL, function handle(retVal){});	
	document.getElementById("elevatordir").innerHTML = "Going Up";
}

function floor(CFL){
	getRequest(postReqPrefix + "floorGoto.php", "Des_Floor", CFL, function handle(retVal){});
	document.getElementById("floorDisplay").innerHTML = CFL;
}
	
function topFunction() {
	document.body.scrollTop = 0;
	document.documentElement.scrollTop = 0;
}

function colorchange(id, limitSwitch)
{
	var ele = document.getElementById(id);
	var floorlimitswitch = 0;

	if(ele.style.background == "rgb(26, 255, 0)" && limitSwitch == true){
		ele.style.background = "rgb(51,181,229)";
	}else if(ele.style.background != "rgb(26, 255, 0)" && limitSwitch != true){
		ele.style.background = "rgb(26, 255, 0)";
	}
}
	
function getRequest(RQURL, name, value, func){
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			func(this.responseText);
		}
	};
	xhttp.open("POST", RQURL, true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhttp.send(name + "=" + value);	
}

window.addEventListener('load', function() {
	var re = /(?:\.([^.]+))?$/;
	if(re.exec(window.location.pathname)[1] == "php"){
		postReqPrefix = "";
	}else{
		postReqPrefix = "php/";
	}
}, false);
